# 開発・変更

現在はBLOCK 2の公開準備版（0.2.1）です。BLOCK 3以降の追加は別の開発単位として扱います。

1. Python仮想環境へrequirements-dev.txtをconstraints.txt付きで導入。
2. python -m pytest -q、npm run checkを実行。
3. python scripts/build_pages.py、npm testを実行。
4. Git管理下のファイルをpython scripts/check_public_source.pyで確認。
5. README/CHANGELOG/FEATURES/TEST_REPORT/NEXT_BLOCKを更新。
6. python scripts/package.pyで公開用ZIPを生成。

CIはUbuntu/WindowsのPython 3.12を対象に構成しています。GitHub上での実行結果はActionsで確認してください。
ローカルの検証結果とGitHub Actionsの成功を混同しないでください。

生成物dist/、利用中DB、backup、実ログ、.envはGit対象にしません。
DB移行テストの元データはtests/fixtures/block1_seed.sqlにある架空データです。
Pagesデモに実株価を埋め込む変更は行わず、実データは既存のBackend API経由で扱います。

オープンソースライセンスは未選択です。公開準備で権利者に代わってMIT等の許諾を付与していません。
OSSとして配布する場合は、リポジトリ所有者がライセンスを決めてLICENSEを追加してください。
