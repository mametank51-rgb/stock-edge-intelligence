# Security / 公開範囲

GitHub Pagesで公開するものは固定の架空データと静的Frontendだけです。
Pagesデモの保存は閲覧者のブラウザ内です。サーバーのSQLiteや共有ユーザーデータを公開しません。

Backendは引き続きローカル/閉域で1ユーザーが使う構成です。認証・ユーザー分離・公開サービス向けの運用対策は未実装です。
GitHubへのソース公開と、Backendの一般公開は別の作業です。
Backendを外部へホストする場合は、アクセス制御・HTTPS・データ提供元の利用範囲を別途設計してください。
今回、Backendを外部へ配置・公開する処理は追加していません。

- 実キーはBackendの.envまたはホストの環境変数へ設定する。
- JQUANTS_API_KEYをGitHub、Pages、Actions用公開変数、JavaScriptへ入れない。
- 利用中DB、backup、ログ、秘密設定をコミットしない。
- 公開ZIPはscripts/package.pyで生成する。作業フォルダ全体を圧縮してアップロードしない。
- CIは実キー不要のテストを実行する。pull_request_targetや書込権限付きPR実行は使わない。
- キーを誤って公開した場合は、ファイルの削除だけでなく提供元で失効・再発行する。

脆弱性の報告では、キーや個人データを公開Issueへ貼り付けないでください。
リポジトリ所有者がGitHubのPrivate vulnerability reportingを有効化した場合はそちらを使用してください。
連絡先や所有者の情報は、この成果物では仮定していません。
