# NEXT BLOCK — BLOCK 3への引継ぎ

## 現在地

v0.2.1 / BLOCK 2のGitHub公開準備版。BLOCK 1のコードを継承し、取得・保存・キャッシュ・表示とPagesデモを追加しました。
次はBLOCK 3 Basic Technical Engineです。ユーザーの指示前に進めないでください。

## 最初に行うこと

1. README、DATA_PROVIDERS、MIGRATION、TEST_REPORTを読む。
2. `python -m pytest -q`で63件、`npm run check`、`python scripts/build_pages.py`、`npm test`（9件）を実行する。
3. 利用DBをバックアップし、既存コードへ追加する。ゼロから作り直さない。
4. 実APIキーは成果物・画面・ログへ出さない。現在の実接続未検証を成功扱いしない。

## BLOCK 3の範囲

- SMA（期間設定）、EMA、RSI、MACD、Bollinger Bands、ATR。
- Volumeの表示/必要な基礎評価、basic trend。
- 日足と週足それぞれの表示データと計算期間を明示する。
- 指標をチャートへ描画し、Technical summaryへ数値と根拠を表示する。
- 指標不足期間はnull/未算出。0や中立値で水増ししない。
- 時系列の未来参照を避け、計算定義・初期値・平滑化方法・warm-upを記録する。
- Indicator計算はLLMではなく再現可能な数値ロジックにする。

Swing/ライン/パターンはBLOCK 4/5、シナリオは6、財務等は7以降です。
Meta Edgeや実買い候補ランキングを先行実装しないでください。

## データについて

- `market_data.get_prices`はPriceSeriesを返します。candles、basis、interval、data_as_of、fetched_at、source、is_dummyを保持します。
- 基本の分析入力はadjusted OHLCVを推奨しますが、採用方針を決めて必ず表示・保存してください。
- raw/adjusted、日足/週足を混ぜて計算しない。
- 週足は進行中/境界が未確定の可能性を持ちます。確定足だけ使うか区別する。
- 調整済み値は遡及修正され得ます。point-in-time backtestを完成扱いにしない。
- 無約定日/祝日を補完していません。観測本数ベースか営業日ベースか定義を明示。
- 実在銘柄のFundamental/Intelligence/Market/Edge等は引き続きnull。
- Dummyの固定値と計算済みTechnical値を明確に区別する。

## 拡張境界

| ファイル | 役割 |
|---|---|
| backend/providers.py | 公式API Adapter。分析を入れず維持 |
| backend/market_data.py | 取得・fallback・週足集約。取得日時を分析実行日時と混同しない |
| backend/market_models.py | 日足/表示足/PriceSeries |
| backend/models.py | 設定・スコア・将来用契約 |
| backend/repository.py | SQLと移行。現在schema version 2 |
| frontend/assets/api.js | health.block===2のチェックを新BLOCKへ更新 |
| frontend/assets/chart.js | SVG描画境界。指標用overlay/paneを追加可能 |
| frontend/assets/app.js | 5画面と足種/調整/検索操作 |
| frontend/assets/market-view.js | 取得情報・検索・提供元設定 |

新たにanalysis/indicators.py等へ計算を分離し、取得処理に混ぜないこと。
DBを変更するなら明示的なv2→v3移行、バックアップ、既存データ保持検証を追加します。
health.block/source/mode、UIラベル、manifest、ドキュメント、ZIPルート名も更新してください。

## 回帰チェック

- Providerの正常/異常系、TTL、429/cooldown、キャッシュ失敗時の元日時維持。
- 銘柄検索・登録、4/5桁・英字コード、sourceとis_dummyの分離。
- raw/adjusted、日足/週足、価格/騰落率の整合性。
- 5画面、モバイル390px、ウォッチ・テーマ・提供元設定の再起動保持。
- v1→v2および追加する移行、外部キー、旧DBのバックアップ。
- 指標は独立した既知系列・定義値で検証する。実装をなぞるだけのテストにしない。

## 次回の必須成果物

完全ソース・起動可能版・README・CHANGELOG（変更ファイル一覧）・FEATURES・NEXT_BLOCK・TEST_REPORT・PROJECT_TREE。
配布ZIP・GitにはDBを含めず、初回起動で作成すること。利用中DB・秘密.env・実行ログを公開しない。
Pagesデモのruntime='browser-demo'とBackend版を維持し、片方だけ動く変更を避ける。
変更後はscripts/build_pages.py、公開ファイル検査、リポジトリ名付きURLも回帰確認する。
