@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3 -m venv .venv
  if errorlevel 1 goto :error
)
.venv\Scripts\python.exe -m pip install -r requirements.txt -c constraints.txt
if errorlevel 1 goto :error
echo Open http://127.0.0.1:8000 in your browser. Ctrl+C to stop.
.venv\Scripts\python.exe run.py
if errorlevel 1 goto :error
exit /b 0
:error
echo Startup failed. See the error above. Python 3.11 or newer is required.
pause
exit /b 1
