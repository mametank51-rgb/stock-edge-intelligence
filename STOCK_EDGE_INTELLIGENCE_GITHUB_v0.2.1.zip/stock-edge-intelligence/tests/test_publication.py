import json
import os
import subprocess
import sys
from html.parser import HTMLParser
from pathlib import Path
from zipfile import ZipFile

from scripts.build_pages import ROOT,build
from scripts.check_public_source import audit
from scripts.package import package,source_files


def test_pages_subpath_safe_and_only_static_files(tmp_path,monkeypatch):
    monkeypatch.setenv('JQUANTS_API_KEY','PAGES_MUST_NOT_EXPORT_THIS_SENTINEL')
    output=build(tmp_path/'repository')
    class Links(HTMLParser):
        paths=[]
        def handle_starttag(self,tag,attrs):
            for key,value in attrs:
                if key in ('href','src') and value and not value.startswith('#'):
                    self.paths.append(value)
    parser=Links();parser.feed((output/'index.html').read_text())
    assert parser.paths and all(p.startswith('./') for p in parser.paths)
    assert all((output/p).is_file() for p in parser.paths)
    assert json.loads((output/'manifest.webmanifest').read_text())['start_url']=='./'
    assert json.loads((output/'assets/deployment.json').read_text())['mode']=='pages-demo'
    for path in output.rglob('*'):
        if path.is_file():
            assert 'PAGES_MUST_NOT_EXPORT_THIS_SENTINEL' not in path.read_text()
            assert path.suffix not in ('.py','.db','.sql')
    assert not (output/'backend').exists()
    assert json.loads((ROOT/'frontend/assets/deployment.json').read_text())['mode']=='backend'


def test_public_source_archive_excludes_all_databases_and_includes_workflows(tmp_path):
    archive=tmp_path/'source.zip'
    env=os.environ.copy();env.pop('PYTHONPATH',None)
    result=subprocess.run([sys.executable,str(ROOT/'scripts/package.py'),str(archive)],cwd=tmp_path,env=env,capture_output=True,text=True)
    assert result.returncode==0,result.stdout+result.stderr
    with ZipFile(archive) as z:
        paths=z.namelist()
        for name in ('.github/workflows/ci.yml','.github/workflows/pages.yml','tests/fixtures/block1_seed.sql',
                     'GITHUB_PUBLISH.md','SECURITY.md','frontend/assets/deployment.json'):
            assert 'stock-edge-intelligence/'+name in paths
        assert not any(n.endswith(('.db','.bak','.log','.pem','.key')) or '/.env.' in n for n in paths if not n.endswith('/.env.example'))
        assert not any('/preview_dependencies/' in n or '/dist/' in n for n in paths)


def test_file_audit_rejects_private_files_without_printing_contents(tmp_path):
    db=tmp_path/'personal.db';db.write_bytes(b'private')
    env=tmp_path/'.env';env.write_text('JQUANTS_API_KEY=DO_NOT_PRINT_THIS_VALUE')
    errors=audit(tmp_path,[db,env])
    assert len(errors)==2 and all('DO_NOT_PRINT' not in e for e in errors)
    example=tmp_path/'.env.example';example.write_text('JQUANTS_API_KEY=NOT_EMPTY')
    assert audit(tmp_path,[example])
    example.write_text('JQUANTS_API_KEY=\nJQUANTS_PLAN=free\n')
    assert audit(tmp_path,[example])==[]


def test_source_selection_excludes_nested_backups_and_secret_env(tmp_path):
    for name in ['backend/main.py','backend/.env.local','database/backups/backup.db','frontend/assets/secret.key']:
        path=tmp_path/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('test')
    assert [p.relative_to(tmp_path).as_posix() for p in source_files(tmp_path)]==['backend/main.py']


def test_workflow_scope_and_permissions():
    ci=(ROOT/'.github/workflows/ci.yml').read_text()
    pages=(ROOT/'.github/workflows/pages.yml').read_text()
    assert 'pull_request_target' not in ci
    assert 'contents: read' in ci and 'contents: write' not in ci
    assert 'workflow_dispatch:' in pages and '\n  push:' not in pages
    assert 'path: dist/pages' in pages and 'needs: build' in pages
