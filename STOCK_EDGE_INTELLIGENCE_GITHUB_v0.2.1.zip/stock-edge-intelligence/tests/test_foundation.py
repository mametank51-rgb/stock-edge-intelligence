import json
import sqlite3
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from backend.main import create_app
from backend.models import AppSettings
from backend.repository import SQLiteRepository


@pytest.fixture
def db_path(tmp_path):
    return tmp_path / "foundation.db"


@pytest.fixture
def client(db_path):
    with TestClient(create_app(db_path)) as instance:
        yield instance


def test_boot_and_required_api(client):
    health = client.get("/health")
    assert health.status_code == 200
    assert health.json()["database"] == {"status": "ok", "schema_version": 2, "stock_count": 8}
    for route in ("/stocks", "/stocks/DMY001", "/ranking", "/settings", "/watchlist"):
        assert client.get(route).status_code == 200


def test_fictional_identity_and_score_contract(client):
    stocks = client.get("/stocks").json()
    assert len(stocks) == 8
    assert all(s["is_dummy"] and s["source"] == "BLOCK1_SYNTHETIC" for s in stocks)
    assert all("架空" in s["company"] and s["ticker"].startswith("DMY") for s in stocks)
    keys = {"technical", "fundamental", "intelligence", "market", "opportunity", "risk", "edge", "conviction", "signal_diversity", "conflict"}
    for stock in stocks:
        assert set(stock["scores"]) == keys
        assert all(0 <= score <= 100 for score in stock["scores"].values())


def test_price_integrity_for_every_stock(client):
    for stock in client.get("/stocks").json():
        history = client.get(f'/stocks/{stock["ticker"]}/prices').json()
        assert history["is_dummy"] and history["interval"] == "1d"
        candles = history["candles"]
        assert len(candles) == 160
        assert len({c["time"] for c in candles}) == 160
        assert [c["time"] for c in candles] == sorted(c["time"] for c in candles)
        for candle in candles:
            assert 0 < candle["low"] <= min(candle["open"], candle["close"])
            assert candle["high"] >= max(candle["open"], candle["close"])
            assert candle["volume"] >= 0
        assert candles[-1]["close"] == stock["price"]
        assert round((candles[-1]["close"]/candles[-2]["close"]-1)*100,2) == stock["change_pct"]


def test_ranking_is_only_sorted_fixture_data(client):
    ranking = client.get("/ranking").json()
    assert [s["scores"]["edge"] for s in ranking] == sorted([s["scores"]["edge"] for s in ranking], reverse=True)
    assert {s["ticker"] for s in ranking} == {s["ticker"] for s in client.get("/stocks").json()}


def test_watchlist_add_duplicate_and_delete(client):
    assert len(client.get("/watchlist").json()) == 3
    for _ in range(2):
        assert client.put("/watchlist/DMY005").json()["saved"]
    assert len(client.get("/watchlist").json()) == 4
    for _ in range(2):
        assert client.delete("/watchlist/DMY005").json()["saved"] is False
    assert len(client.get("/watchlist").json()) == 3


def test_db_preserves_empty_watchlist_and_settings_on_restart(db_path):
    with TestClient(create_app(db_path)) as client:
        for stock in client.get("/watchlist").json():
            client.delete('/watchlist/'+stock["ticker"])
        assert client.patch("/settings", json={"theme":"light","debug_mode":True}).status_code == 200
    with TestClient(create_app(db_path)) as client:
        assert client.get("/watchlist").json() == []
        settings = client.get("/settings").json()
        assert settings["theme"] == "light" and settings["debug_mode"] is True
        assert len(client.get("/stocks").json()) == 8
        assert len(client.get("/stocks/DMY001/prices").json()["candles"]) == 160


@pytest.mark.parametrize("patch", [
    {"theme":"purple"}, {"market":"US"}, {"theme":None}, {"unknown":"no"},
    {"weights":{"5":{"technical":20,"fundamental":20,"intelligence":20,"market":20}}},
    {"weights":{}},
])
def test_invalid_settings_are_atomic(client,patch):
    before = client.get("/settings").json()
    assert client.patch("/settings",json=patch).status_code == 422
    assert client.get("/settings").json() == before


def test_configurable_weights_storage_without_scoring(client):
    ranking_before = client.get("/ranking").json()
    settings = client.get("/settings").json()
    settings["weights"]["5"] = {"technical":40,"fundamental":30,"intelligence":20,"market":10}
    result = client.patch("/settings",json={"weights":settings["weights"]})
    assert result.status_code == 200
    assert client.get("/settings").json()["weights"]["5"]["technical"] == 40
    assert client.get("/ranking").json() == ranking_before


def test_missing_stock_and_watchlist_rejection(client):
    for method,path in [("get","/stocks/UNKNOWN"),("get","/stocks/UNKNOWN/prices"),
                        ("put","/watchlist/UNKNOWN"),("delete","/watchlist/UNKNOWN")]:
        assert getattr(client,method)(path).status_code == 404
    assert len(client.get("/watchlist").json()) == 3


def test_database_keys_constraints_and_integrity(db_path,client):
    with sqlite3.connect(db_path) as connection:
        connection.execute("PRAGMA foreign_keys=ON")
        assert connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert connection.execute("PRAGMA foreign_key_check").fetchall() == []
        assert connection.execute("SELECT count(*) FROM price_history").fetchone()[0] == 1280
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute("INSERT INTO watchlist VALUES('UNKNOWN','2026-10-23')")
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute("INSERT INTO price_history VALUES('DMY001','2026-10-24',100,90,95,100,10)")


def test_static_shell_and_no_service_worker(client):
    for path in ("/", "/assets/app.js", "/assets/api.js", "/assets/chart.js", "/assets/styles.css", "/icons/icon.svg", "/manifest.webmanifest"):
        response=client.get(path)
        assert response.status_code == 200
        assert response.headers["x-content-type-options"] == "nosniff"
    assert "STOCK EDGE" in client.get("/").text
    assert "serviceWorker.register" not in client.get("/assets/app.js").text


def test_cors_and_database_error_response(db_path,client):
    allowed=client.options("/watchlist/DMY001",headers={"Origin":"http://localhost:5173","Access-Control-Request-Method":"PUT"})
    assert allowed.status_code == 200
    assert allowed.headers["access-control-allow-origin"] == "http://localhost:5173"
    denied=client.options("/settings",headers={"Origin":"https://untrusted.invalid","Access-Control-Request-Method":"PATCH"})
    assert denied.status_code == 400
    repo=client.app.state.repository
    original=repo.get_settings
    def broken():
        raise sqlite3.OperationalError("test database unavailable")
    repo.get_settings=broken
    response=client.get("/settings")
    assert response.status_code == 503
    assert "test database" not in response.text
    repo.get_settings=original
    assert client.get("/health").status_code == 200


def test_malformed_json_rejected(client):
    assert client.patch("/settings",content="{oops",headers={"Content-Type":"application/json"}).status_code == 422


def test_db_schema_downgrade_refused(db_path):
    repo = SQLiteRepository(db_path)
    repo.initialize()
    with sqlite3.connect(db_path) as conn:
        conn.execute("PRAGMA user_version=999")
    with pytest.raises(RuntimeError,match="newer"):
        repo.initialize()
