"""Restore the original BLOCK 1 synthetic snapshot without distributing SQLite bytes."""
import sqlite3
from pathlib import Path


def restore_v1_database(destination):
    sql=(Path(__file__).parent/'fixtures/block1_seed.sql').read_text(encoding='utf-8')
    connection=sqlite3.connect(destination)
    try:
        connection.executescript(sql)
    finally:
        connection.close()
