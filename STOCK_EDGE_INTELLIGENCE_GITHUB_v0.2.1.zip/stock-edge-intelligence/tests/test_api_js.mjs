// No browser package or external connection required; check connection validation.
import assert from 'node:assert/strict';
globalThis.location = {protocol:'http:'};
const {normalizeBackend} = await import('../frontend/assets/api.js');
assert.equal(normalizeBackend(''), '');
assert.equal(normalizeBackend(' http://localhost:8000/ '), 'http://localhost:8000');
for (const invalid of ['javascript:alert(1)','https://user:secret@example.com','https://example.com/api','https://example.com/?key=secret','https://example.com/#x']) {
  assert.throws(()=>normalizeBackend(invalid));
}
globalThis.location = {protocol:'https:'};
assert.throws(()=>normalizeBackend('http://localhost:8000'));
assert.equal(normalizeBackend('https://example.com'), 'https://example.com');
console.log('PASS: Backend URL validation (10 assertions)');
