import test from 'node:test';
import assert from 'node:assert/strict';
import {request} from '../frontend/assets/api.js';

test('Explicit backend uses network transport without loading Pages fixtures',async()=>{
  const original=globalThis.fetch;const calls=[];
  globalThis.fetch=async(url,options)=>{
    calls.push({url,options});return {ok:true,json:async()=>({runtime:'backend',status:'ok'})};
  };
  try {
    const result=await request('/health',{},'https://backend.example.invalid');
    assert.equal(result.runtime,'backend');assert.equal(calls.length,1);
    assert.equal(calls[0].url,'https://backend.example.invalid/health');
    assert.equal(calls[0].options.credentials,'omit');
  } finally {globalThis.fetch=original;}
});
test('Backend failure never falls back to browser demo',async()=>{
  const original=globalThis.fetch;let calls=0;
  globalThis.fetch=async()=>{calls++;throw new TypeError('offline');};
  try {
    await assert.rejects(request('/stocks',{},'https://backend.example.invalid'),/Backendに接続できません/);
    assert.equal(calls,1);
  } finally {globalThis.fetch=original;}
});
