import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createDemo} from '../frontend/assets/demo-core.js';
const data=JSON.parse(await readFile(new URL('../dist/pages/assets/demo-data.json',import.meta.url),'utf8'));
function fixture() {
  const values=new Map();
  const storage={getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,v)};
  const now=()=>new Date('2026-10-24T06:00:00Z');
  return {call:createDemo(data,storage,now),storage,now};
}

test('Pages runtime is explicitly local and fictional',async()=>{
  const {call}=fixture();const health=await call('/health');
  assert.equal(health.runtime,'browser-demo');assert.equal(health.mode,'dummy');
  assert.equal(health.database.status,'browser-local');
  assert.equal((await call('/stocks')).length,8);
  assert.ok((await call('/stocks')).every(s=>s.is_dummy));
});
test('Watchlist saves, deduplicates, deletes, and survives an instance restart',async()=>{
  const {call,storage,now}=fixture();
  await call('/watchlist/DMY004',{method:'PUT'});await call('/watchlist/DMY004',{method:'PUT'});
  assert.equal((await call('/watchlist')).length,4);
  for(const s of await call('/watchlist')) await call('/watchlist/'+s.ticker,{method:'DELETE'});
  assert.deepEqual(await createDemo(data,storage,now)('/watchlist'),[]);
});
test('Settings persist without accepting real provider secrets or modes',async()=>{
  const {call,storage,now}=fixture();
  await call('/settings',{method:'PATCH',body:JSON.stringify({theme:'light',debug_mode:true})});
  assert.equal((await createDemo(data,storage,now)('/settings')).theme,'light');
  const before=await call('/settings');
  await assert.rejects(call('/settings',{method:'PATCH',body:JSON.stringify({market_data_provider:'jquants'})}));
  await assert.rejects(call('/settings',{method:'PATCH',body:JSON.stringify({theme:'purple'})}));
  assert.deepEqual(await call('/settings'),before);
});
test('Daily/weekly views keep original fixture prices and dates',async()=>{
  const {call}=fixture();const daily=await call('/stocks/DMY001/prices');
  const weekly=await call('/stocks/DMY001/prices?interval=1wk');
  assert.equal(daily.candles.length,160);assert.equal(weekly.candles.length,32);
  assert.equal(weekly.candles[0].time,'2026-03-16');
  assert.equal(weekly.candles.at(-1).close,daily.candles.at(-1).close);
  assert.equal(weekly.candles.reduce((a,c)=>a+c.volume,0),daily.candles.reduce((a,c)=>a+c.volume,0));
  const update=await call('/stocks/DMY001/refresh',{method:'POST'});
  assert.equal(update.data_as_of,'2026-10-23');assert.equal(update.fetched_at,'2026-10-24T06:00:00.000Z');
  assert.ok(update.warnings.some(s=>s.includes('Backend')));
});
test('Search is local, and unknown stocks/operations fail explicitly',async()=>{
  const {call}=fixture();assert.equal((await call('/market/search?q=DMY004')).total_matches,1);
  await assert.rejects(call('/stocks/72030/prices'));
  await assert.rejects(call('/stocks/DMY001/prices?interval=1m'));
  await assert.rejects(call('/unimplemented'));
});
test('Storage failure never reports a successful save',async()=>{
  const storage={getItem:()=>null,setItem:()=>{throw new Error('quota');}};
  const call=createDemo(data,storage);
  await assert.rejects(call('/watchlist/DMY004',{method:'PUT'}),/保存できません/);
  assert.equal((await call('/watchlist')).length,3);
});
