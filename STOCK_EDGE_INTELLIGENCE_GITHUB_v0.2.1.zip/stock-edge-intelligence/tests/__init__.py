"""Application tests, including original synthetic database migrations."""
