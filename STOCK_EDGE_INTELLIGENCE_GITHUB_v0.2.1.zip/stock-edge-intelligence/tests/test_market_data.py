import copy
import json
import sqlite3
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient

from backend.main import create_app
from backend.market_data import weekly_candles
from backend.models import Candle
from backend.providers import DummyProvider, JQuantsProvider, ProviderError, normalize_ticker
from backend.repository import SQLiteRepository
from tests.support import restore_v1_database


NOW=datetime(2026,10,24,6,tzinfo=timezone.utc)
INSTRUMENT={"Date":"2026-07-31","Code":"99990","CoName":"Adapter試験株式会社（架空テスト）",
            "CoNameEn":"Adapter Test Fixture","S33Nm":"テスト業種","MktNm":"プライム","ProdCat":"011"}
BARS=[
    {"Date":"2026-07-30","Code":"99990","O":100,"H":104,"L":98,"C":102,"Vo":1000,
     "AdjO":50,"AdjH":52,"AdjL":49,"AdjC":51,"AdjVo":2000,"AdjFactor":1},
    {"Date":"2026-07-31","Code":"99990","O":51,"H":53,"L":50,"C":52,"Vo":1200,
     "AdjO":51,"AdjH":53,"AdjL":50,"AdjC":52,"AdjVo":1200,"AdjFactor":.5},
]


class Router:
    def __init__(self):
        self.calls=[];self.mode="ok"

    def __call__(self,req):
        self.calls.append(req)
        assert req.url.host=="api.jquants.com"
        assert req.headers["x-api-key"]=="test-secret-never-export"
        assert "test-secret" not in str(req.url)
        if self.mode=="timeout":
            raise httpx.ReadTimeout("private raw transport failure",request=req)
        if self.mode=="auth":
            return httpx.Response(403,json={"secret":"private server response"})
        if self.mode=="rate":
            return httpx.Response(429,headers={"Retry-After":"17"})
        if self.mode=="invalid":
            return httpx.Response(200,content=b"not json")
        if self.mode=="empty":
            return httpx.Response(200,json={"data":[]})
        if req.url.path.endswith("/master"):
            assert req.url.params["date"]=="2026-08-01"  # Free = 84 days delayed.
            extra={**INSTRUMENT,"Code":"186A0","CoName":"英字コード試験（架空）","CoNameEn":"Alphabet Code Fixture"}
            etf={**INSTRUMENT,"Code":"12340","ProdCat":"014"}
            return httpx.Response(200,json={"data":[INSTRUMENT,extra,etf]})
        assert req.url.path=="/v2/equities/bars/daily"
        assert req.url.params["code"]=="99990"
        assert req.url.params["to"]=="2026-08-01"
        rows=copy.deepcopy(BARS)
        null={"Date":"2026-07-29","Code":"99990",**{k:None for k in ("O","H","L","C","Vo","AdjO","AdjH","AdjL","AdjC","AdjVo")}}
        if self.mode=="bad_ohlc":
            rows[0]["H"]=1
        if self.mode=="page_failure":
            if req.url.params.get("pagination_key"):
                return httpx.Response(503,json={"message":"private"})
            return httpx.Response(200,json={"data":[rows[0]],"pagination_key":"page2"})
        return httpx.Response(200,json={"data":[rows[1],null,rows[0],rows[1]]})


def make_provider(router,**kwargs):
    return JQuantsProvider(api_key="test-secret-never-export",plan="free",
        today=lambda:NOW.date(),client=httpx.Client(transport=httpx.MockTransport(router),trust_env=False),**kwargs)


@pytest.fixture
def market_client(tmp_path):
    router=Router();provider=make_provider(router)
    current=[NOW]
    app=create_app(tmp_path/'market.db',providers={"dummy":DummyProvider(),"jquants":provider},now=lambda:current[0])
    with TestClient(app) as client:
        yield client,router,provider,current


def prepare_real(client):
    assert client.patch('/settings',json={"market_data_provider":"jquants"}).status_code==200
    assert client.post('/market/catalog/refresh').status_code==200


@pytest.mark.parametrize('value,expected',[("7203","72030"),("７２０３","72030"),("186a","186A0"),
    ("186A0","186A0"),("72035","72035"),("7203.T","72030"),("dmy001","DMY001")])
def test_code_normalization(value,expected):
    assert normalize_ticker(value)==expected


@pytest.mark.parametrize('value',["foo","../7203","72030?key=x","A123","720300",""])
def test_invalid_code_rejected(value):
    with pytest.raises(ValueError):
        normalize_ticker(value)


def test_v1_migration_preserves_exact_user_data_and_backup(tmp_path):
    path=tmp_path/'existing.db'
    restore_v1_database(path)
    with sqlite3.connect(path) as conn:
        assert conn.execute('pragma user_version').fetchone()[0]==1
        conn.execute('DELETE FROM watchlist')
        settings=json.loads(conn.execute("SELECT value FROM settings WHERE key='app'").fetchone()[0])
        settings.update(theme='light',debug_mode=True)
        settings.pop('market_data_provider',None)
        settings['weights']['5']={"technical":40,"fundamental":30,"intelligence":20,"market":10}
        conn.execute("UPDATE settings SET value=? WHERE key='app'",(json.dumps(settings),))
        before=conn.execute('SELECT * FROM price_history ORDER BY ticker,date').fetchall()
        before_stocks=conn.execute('SELECT * FROM stocks ORDER BY ticker').fetchall()
    repo=SQLiteRepository(path);repo.initialize();repo.initialize()
    assert repo.get_settings().theme=='light' and repo.get_settings().debug_mode
    assert repo.get_settings().weights['5'].technical==40
    assert repo.get_settings().market_data_provider=='dummy'
    assert repo.list_watchlist()==[]
    with sqlite3.connect(path) as conn:
        assert conn.execute('pragma user_version').fetchone()[0]==2
        assert conn.execute('SELECT * FROM price_history ORDER BY ticker,date').fetchall()==before
        assert conn.execute('SELECT * FROM stocks ORDER BY ticker').fetchall()==before_stocks
        assert conn.execute('SELECT count(*) FROM price_adjustments').fetchone()[0]==1280
        assert conn.execute('pragma foreign_key_check').fetchall()==[]
    backup=tmp_path/'backups/existing.db.v1.bak'
    with sqlite3.connect(backup) as conn:
        assert conn.execute('pragma user_version').fetchone()[0]==1
        assert conn.execute('SELECT * FROM price_history ORDER BY ticker,date').fetchall()==before


def test_catalog_normalization_search_and_key_privacy(market_client):
    c,router,_,_=market_client
    prepare_real(c)
    result=c.get('/market/search?q=186a').json()
    assert result['total_catalog']==2 and result['items'][0]['ticker']=='186A0'
    assert c.get('/market/search?q=Adapter').json()['total_matches']==1
    assert c.get('/market/search?q=テスト業種').json()['total_matches']==2
    for endpoint in ['/health','/market/providers','/settings','/market/search']:
        assert 'test-secret-never-export' not in c.get(endpoint).text
    assert c.get('/stocks').json()==[]


def test_raw_adjusted_import_and_weekly_without_dummy_scores(market_client):
    c,router,_,_=market_client
    prepare_real(c)
    imported=c.post('/stocks/9999/refresh')
    assert imported.status_code==200,imported.text
    data=imported.json()
    assert data['ticker']=='99990' and data['is_dummy'] is False
    assert data['source']=='JQUANTS_V2' and data['skipped_rows']==1
    assert data['data_as_of']=='2026-07-31' and data['fetched_at'].startswith('2026-10-24')
    assert len(data['candles'])==2 and data['candles'][0]['close']==51
    assert data['stock']['price']==52 and data['stock']['change_pct']==1.96
    assert all(v is None for v in data['stock']['scores'].values())
    count=len(router.calls)
    raw=c.get('/stocks/9999/prices?basis=raw').json()
    assert raw['candles'][0]['close']==102
    weekly=c.get('/stocks/99990/prices?interval=1wk').json()
    assert len(router.calls)==count  # Fresh cache, both views use same snapshot.
    assert weekly['candles'][0]=={'time':'2026-07-27','open':50,'high':53,'low':49,'close':52,
        'volume':3200,'end_date':'2026-07-31','observed_sessions':2,'is_partial':True}
    assert c.get('/ranking').json()[0]['scores']['edge'] is None
    assert c.put('/watchlist/9999').status_code==200
    assert any(s['ticker']=='99990' for s in c.get('/watchlist').json())
    c.patch('/settings',json={'market_data_provider':'dummy'})
    assert len(c.get('/stocks').json())==8
    assert any(s['ticker']=='99990' for s in c.get('/watchlist').json())


@pytest.mark.parametrize('failure',['timeout','auth','rate','invalid','empty','bad_ohlc','page_failure'])
def test_failed_refresh_keeps_last_known_data_and_time(market_client,failure):
    c,router,_,_=market_client
    prepare_real(c)
    old=c.post('/stocks/99990/refresh').json()
    router.mode=failure
    response=c.post('/stocks/99990/refresh')
    assert response.status_code==200,response.text
    latest=response.json()
    assert latest['cache_status']=='stale_error'
    assert latest['candles']==old['candles']
    assert latest['fetched_at']==old['fetched_at'] and latest['data_as_of']==old['data_as_of']
    assert latest['error_code'] and 'private' not in latest['error_message']
    assert c.get('/health').status_code==200
    assert c.get('/watchlist').status_code==200
    calls=len(router.calls)
    c.get('/stocks/99990/prices')
    assert len(router.calls)==calls  # Prevent automatic failure loops for 60s.


def test_cache_expires_and_upserts_without_duplicates(market_client):
    c,router,_,current=market_client
    prepare_real(c);c.post('/stocks/99990/refresh')
    first_count=len(router.calls)
    current[0]+=timedelta(hours=25)
    response=c.get('/stocks/99990/prices').json()
    assert len(router.calls)==first_count+1
    assert response['cache_status']=='fresh' and response['fetched_at'].startswith('2026-10-25')
    repo=c.app.state.repository
    assert repo.price_count('99990')==2
    assert len(repo.daily_prices('99990'))==2


def test_catalog_failure_uses_saved_catalog(market_client):
    c,router,_,_=market_client
    prepare_real(c)
    before=c.get('/market/search').json()
    router.mode='auth'
    after=c.post('/market/catalog/refresh').json()
    assert after['cache_status']=='stale_error' and after['items']==before['items']
    assert after['fetched_at']==before['fetched_at']


def test_empty_initial_real_request_has_no_fake_prices(market_client):
    c,router,_,_=market_client
    prepare_real(c);router.mode='empty'
    response=c.post('/stocks/99990/refresh')
    assert response.status_code==503 and response.json()['error_code']=='EMPTY'
    assert c.get('/stocks').json()==[]
    assert c.get('/stocks/99990').status_code==404


def test_missing_key_is_safe_and_app_remains_usable(tmp_path):
    provider=JQuantsProvider(api_key='',plan='free')
    with TestClient(create_app(tmp_path/'no-key.db',providers={'dummy':DummyProvider(),'jquants':provider})) as c:
        c.patch('/settings',json={'market_data_provider':'jquants'})
        assert c.get('/health').status_code==200
        r=c.post('/market/catalog/refresh')
        assert r.status_code==503 and r.json()['error_code']=='NOT_CONFIGURED'
        assert c.get('/market/search').json()['total_catalog']==0
        assert c.get('/stocks').json()==[]
        assert len(c.get('/watchlist').json())==3
        assert c.get('/stocks/DMY001/prices').json()['is_dummy'] is True


def test_429_is_not_retried_and_cooldown_is_shared():
    router=Router();router.mode='rate'
    provider=make_provider(router)
    for _ in range(2):
        with pytest.raises(ProviderError) as exc:
            provider.fetch_catalog()
        assert exc.value.code=='RATE_LIMIT' and exc.value.retry_after==17
    assert len(router.calls)==1
    provider.close()


def test_free_request_window_and_local_limit():
    router=Router();provider=make_provider(router)
    for _ in range(5):
        provider.fetch_catalog()
    with pytest.raises(ProviderError) as exc:
        provider.fetch_catalog()
    assert exc.value.code=='RATE_LIMIT' and len(router.calls)==5
    provider.close()


def test_weekly_year_boundary_and_observed_days_only():
    rows=[Candle(time=d,open=o,high=o+4,low=o-2,close=o+1,volume=100) for d,o in [
        ('2025-12-29',100),('2025-12-30',101),('2026-01-02',104),('2026-01-05',110)]]
    weeks=weekly_candles(rows,date(2026,1,7))
    assert len(weeks)==2
    assert weeks[0].time==date(2025,12,29) and weeks[0].close==105 and weeks[0].volume==300
    assert weeks[0].observed_sessions==3 and weeks[0].is_partial is False
    assert weeks[1].is_partial is True


def test_invalid_parameters_and_provider_settings(market_client):
    c,_,_,_=market_client
    for path in ['/stocks/DMY001/prices?interval=1m','/stocks/DMY001/prices?basis=unknown',
                 '/market/search?limit=101','/market/search?q='+'x'*121]:
        assert c.get(path).status_code==422
    assert c.patch('/settings',json={'market_data_provider':'nonexistent'}).status_code==422


def test_malformed_and_inconsistent_data_rejected_before_save():
    cases=[]
    for key,value in [('H',1),('AdjL',200),('Vo',-1),('AdjC',None),('C',float('inf')),('O',True),('Code','12340'),('Date','2099-01-01')]:
        row=copy.deepcopy(BARS[0]);row[key]=value;cases.append(row)
    for row in cases:
        def respond(req):
            # Infinity is non-JSON by design; emit it as invalid JSON to exercise rejection.
            return httpx.Response(200,content=json.dumps({'data':[row]}).encode())
        provider=make_provider(respond)
        instrument=DummyProvider().fetch_catalog()[0].model_copy(update={'ticker':'99990','provider_id':'jquants','is_dummy':False})
        with pytest.raises(ProviderError) as exc:
            provider.fetch_daily(instrument)
        assert exc.value.code=='INVALID_DATA'
        provider.close()


def test_pagination_success_loop_and_second_page_error():
    calls=[]
    def handler(req):
        calls.append(req)
        page=req.url.params.get('pagination_key')
        return httpx.Response(200,json={'data':[BARS[1]]} if page else {'data':[BARS[0]],'pagination_key':'next'})
    provider=make_provider(handler)
    instrument=DummyProvider().fetch_catalog()[0].model_copy(update={'ticker':'99990','provider_id':'jquants','is_dummy':False})
    bars,_=provider.fetch_daily(instrument)
    assert len(bars)==2 and len(calls)==2
    provider.close()
    provider=make_provider(lambda req:httpx.Response(200,json={'data':[],'pagination_key':'same'}))
    with pytest.raises(ProviderError) as exc:
        provider.fetch_daily(instrument)
    assert exc.value.code=='PAGINATION'
    provider.close()


def test_conflicting_duplicate():
    instrument=DummyProvider().fetch_catalog()[0].model_copy(update={'ticker':'99990','provider_id':'jquants','is_dummy':False})
    duplicate={**BARS[0],'C':101}
    provider=make_provider(lambda req:httpx.Response(200,json={'data':[BARS[0],duplicate]}))
    with pytest.raises(ProviderError) as exc:
        provider.fetch_daily(instrument)
    assert exc.value.code=='INVALID_DATA'
    provider.close()


def test_real_cache_and_watchlist_survive_restart(tmp_path):
    path=tmp_path/'persist.db';router=Router()
    with TestClient(create_app(path,providers={'dummy':DummyProvider(),'jquants':make_provider(router)},now=lambda:NOW)) as c:
        prepare_real(c);old=c.post('/stocks/99990/refresh').json()
        c.put('/watchlist/99990')
        c.patch('/settings',json={'theme':'light'})
    unavailable=JQuantsProvider(api_key='',plan='free')
    with TestClient(create_app(path,providers={'dummy':DummyProvider(),'jquants':unavailable},now=lambda:NOW)) as c:
        assert c.get('/settings').json()['theme']=='light'
        assert c.get('/settings').json()['market_data_provider']=='jquants'
        assert any(s['ticker']=='99990' for s in c.get('/watchlist').json())
        cached=c.get('/stocks/99990/prices').json()
        assert cached['candles']==old['candles'] and cached['fetched_at']==old['fetched_at']
        failed=c.post('/stocks/99990/refresh').json()
        assert failed['error_code']=='NOT_CONFIGURED' and failed['cache_status']=='stale_error'
        assert failed['candles']==old['candles'] and failed['fetched_at']==old['fetched_at']


def test_single_bar_unknown_change_is_null(tmp_path):
    def single(req):
        return httpx.Response(200,json={'data':[INSTRUMENT] if req.url.path.endswith('/master') else [BARS[0]]})
    with TestClient(create_app(tmp_path/'single.db',providers={'dummy':DummyProvider(),'jquants':make_provider(single)},now=lambda:NOW)) as c:
        prepare_real(c)
        imported=c.post('/stocks/99990/refresh').json()
        assert imported['stock']['change_pct'] is None
        assert c.get('/stocks').json()[0]['change_pct'] is None


def test_parallel_refresh_has_one_writer_and_cached_busy_response(tmp_path):
    import threading
    from concurrent.futures import ThreadPoolExecutor
    from backend.market_data import MarketDataService
    started=threading.Event();release=threading.Event()
    class SlowDummy(DummyProvider):
        calls=0
        def fetch_daily(self,instrument):
            self.calls+=1;started.set()
            assert release.wait(timeout=3)
            return super().fetch_daily(instrument)
    provider=SlowDummy();repo=SQLiteRepository(tmp_path/'parallel.db');repo.initialize()
    service=MarketDataService(repo,providers={'dummy':provider},now=lambda:NOW)
    with ThreadPoolExecutor(max_workers=1) as executor:
        future=executor.submit(service.get_prices,'DMY001','1d','adjusted',True)
        try:
            assert started.wait(timeout=2)
            other=service.get_prices('DMY001',force=True)
            assert other.cache_status=='stale_error' and other.error_code=='BUSY'
            assert len(other.candles)==160 and other.fetched_at is None
        finally:
            release.set()
        assert future.result(timeout=3).cache_status=='fresh'
    assert provider.calls==1
    assert service.get_prices('DMY001').error_code is None


def test_failed_schema_migration_rolls_back_all_ddl(tmp_path,monkeypatch):
    import backend.repository as module
    path=tmp_path/'rollback.db'
    restore_v1_database(path)
    fake_root=tmp_path/'source';migration=fake_root/'database/migrations/002_market_data.sql'
    migration.parent.mkdir(parents=True)
    migration.write_text('CREATE TABLE rollback_probe(id INTEGER);\nINSERT INTO nonexistent_table VALUES(1);\nPRAGMA user_version=2;')
    monkeypatch.setattr(module,'ROOT',fake_root)
    with pytest.raises(sqlite3.OperationalError):
        SQLiteRepository(path).initialize()
    with sqlite3.connect(path) as conn:
        assert conn.execute('pragma user_version').fetchone()[0]==1
        assert conn.execute("SELECT name FROM sqlite_master WHERE name='rollback_probe'").fetchall()==[]
        assert conn.execute('SELECT count(*) FROM stocks').fetchone()[0]==8
        assert conn.execute('SELECT count(*) FROM price_history').fetchone()[0]==1280
    assert (tmp_path/'backups/rollback.db.v1.bak').exists()


def test_transient_500_retries_once_then_succeeds():
    router=Router();count=[0]
    def transient(req):
        count[0]+=1
        return httpx.Response(500,json={'message':'private'}) if count[0]==1 else router(req)
    provider=make_provider(transient)
    assert len(provider.fetch_catalog())==2
    assert count[0]==2
    provider.close()
