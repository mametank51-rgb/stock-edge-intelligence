PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS stocks (
    ticker TEXT PRIMARY KEY,
    company TEXT NOT NULL,
    sector TEXT NOT NULL,
    market TEXT NOT NULL,
    exchange TEXT NOT NULL,
    asset_type TEXT NOT NULL,
    currency TEXT NOT NULL,
    price REAL NOT NULL CHECK(price > 0),
    change_pct REAL NOT NULL,
    scores_json TEXT NOT NULL,
    source TEXT NOT NULL,
    is_dummy INTEGER NOT NULL CHECK(is_dummy IN (0,1)),
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS price_history (
    ticker TEXT NOT NULL REFERENCES stocks(ticker),
    date TEXT NOT NULL,
    open REAL NOT NULL CHECK(open > 0),
    high REAL NOT NULL CHECK(high >= open AND high >= close),
    low REAL NOT NULL CHECK(low <= open AND low <= close AND low > 0),
    close REAL NOT NULL CHECK(close > 0),
    volume INTEGER NOT NULL CHECK(volume >= 0),
    PRIMARY KEY(ticker, date)
);

CREATE TABLE IF NOT EXISTS watchlist (
    ticker TEXT PRIMARY KEY REFERENCES stocks(ticker),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

PRAGMA user_version = 1;
