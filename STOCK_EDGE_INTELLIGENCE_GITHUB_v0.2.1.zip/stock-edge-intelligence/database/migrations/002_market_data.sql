CREATE TABLE instruments (
    provider_id TEXT NOT NULL,
    ticker TEXT NOT NULL,
    company TEXT NOT NULL,
    company_en TEXT NOT NULL,
    sector TEXT NOT NULL,
    exchange TEXT NOT NULL,
    market TEXT NOT NULL,
    currency TEXT NOT NULL,
    is_dummy INTEGER NOT NULL CHECK(is_dummy IN (0,1)),
    snapshot_date TEXT NOT NULL,
    PRIMARY KEY(provider_id, ticker)
);

CREATE TABLE price_adjustments (
    ticker TEXT NOT NULL,
    date TEXT NOT NULL,
    adjusted_open REAL NOT NULL CHECK(adjusted_open > 0),
    adjusted_high REAL NOT NULL CHECK(adjusted_high >= adjusted_open AND adjusted_high >= adjusted_close),
    adjusted_low REAL NOT NULL CHECK(adjusted_low > 0 AND adjusted_low <= adjusted_open AND adjusted_low <= adjusted_close),
    adjusted_close REAL NOT NULL CHECK(adjusted_close > 0),
    adjusted_volume REAL NOT NULL CHECK(adjusted_volume >= 0),
    adjustment_factor REAL NOT NULL CHECK(adjustment_factor > 0),
    PRIMARY KEY(ticker, date),
    FOREIGN KEY(ticker,date) REFERENCES price_history(ticker,date) ON DELETE CASCADE
);

CREATE TABLE data_cache (
    resource TEXT PRIMARY KEY,
    provider_id TEXT NOT NULL,
    fetched_at TEXT,
    data_as_of TEXT,
    last_attempt_at TEXT,
    error_code TEXT,
    error_message TEXT,
    skipped_rows INTEGER NOT NULL DEFAULT 0
);

INSERT INTO price_adjustments
SELECT ticker,date,open,high,low,close,volume,1 FROM price_history;

INSERT INTO instruments
SELECT 'dummy',ticker,company,'',sector,exchange,market,currency,is_dummy,substr(updated_at,1,10)
FROM stocks WHERE is_dummy=1;

INSERT INTO data_cache(resource,provider_id,data_as_of)
SELECT 'dummy:' || ticker,'dummy',substr(updated_at,1,10) FROM stocks WHERE is_dummy=1;

PRAGMA user_version = 2;
