# TEST REPORT — BLOCK 2 公開準備版 / v0.2.1

実施日：2026-10-24 JST。

## 結論と境界

Python **63 passed**、Node **9 passed**（接続URL10項目を含む）、Python/JavaScript構文チェックPASS。
BLOCK 1変更前に19テストを実行しPASS、その後は互換性のあるschema期待値だけ1→2へ更新して継続しました。
日足/週足・価格調整・キャッシュ・失敗時fallback・DB移行・既存保存機能を検証しています。

J-Quantsの実APIキーがないため、**実接続・実価格の照合は未検証**です。
公式仕様に基づくAdapterと、HTTP MockTransportの検証を実接続成功と区別しています。
実際のUvicorn→ブラウザ通信はDummyProviderとキー未設定のエラー経路で確認しました。

## 環境

Python 3.12 / FastAPI 0.162.0 / Uvicorn 0.54.0 / Pydantic 2.14.1 / SQLite 3系 / httpx 0.28.1 / pytest 9.1.1。
Node.js 24.22.1、リモートChromium、390×844 CSS px iframe viewport。
主要依存はrequirements/constraintsに固定しています。

## 自動テスト

| 分類 | 検証内容 |
|---|---|
| BLOCK 1回帰 | 5必須API、架空identity、10スコア、全OHLCV、固定順位、watch CRUD/重複防止、設定、再起動保持、DB制約、CORS/エラー、静的配信 |
| コード正規化 | 4/5桁、全角、英字、.T、DMY、大文字小文字、パス/不正形式拒否 |
| v1→v2 | 実配布DB fixtureを移行。全価格1,280行・stocksの全列が一致、空watchlist・テーマ・Debug・重み保持、backupのv1確認 |
| 銘柄一覧 | 国内株式のみ、英字コード、日本語/英語/業種検索、実データ未取得は空一覧 |
| 価格取得 | Code/from/to・84日遅延、日付昇順、同一重複除去、無約定スキップ |
| 価格調整 | raw/adjustedの違い、分割を跨ぐ比較、ヘッダー価格・調整済み騰落率、単一価格時null |
| 週足 | OHLC・出来高合計、月曜キー、観測数、境界/進行週、年跨ぎ |
| TTL | 新鮮キャッシュでは表示切替で再通信しない、期限超過時に取得・重複なし |
| 失敗×7 | timeout、403、429、不正JSON、空、OHLC不正、ページ途中失敗で元価格・元fetched_at・data_as_of保持 |
| 再試行 | 429を即retryしない、cooldown共有、Freeの5回/分、失敗後60秒の自動ループ抑制 |
| ページング | 正常2ページ、同一cursorループ検出、途中失敗時に部分保存なし |
| 不正値 | 負の出来高、Inf、bool、部分null、誤ticker、範囲外日付、OHLC上下限、矛盾重複 |
| 未設定 | キーなし503、アプリ/health/watchは使用可、実データの架空代替なし |
| 再起動 | 実データcache・watch・テーマ・provider保持、キーが失われても既存価格を保持 |
| 排他・移行失敗 | 同時更新は1writer、他方は保存済み値を表示。移行SQL失敗はDDLごとrollbackしv1を維持 |
| 一過性エラー | 500→200の限定retryで復帰し、無制限再試行しない |
| 秘密情報 | query/公開APIレスポンスにテストキーなし。上流本文をエラー表示へ流さない |

テストは一時DB・HTTPモックを使います。公開ZIPに利用DBはありません。模擬社名はテスト用と明記しています。
pytest.iniでtests/だけを探索し、preview依存ライブラリ自身のテストを件数に含めません。
価格取得の成功後に未調整/調整済み/週足を切り替えても、同じキャッシュを使うことをAPI呼出し回数で検証しました。

## Syntax / Runtime

- `python -m compileall -q backend run.py scripts`：PASS。
- `npm run check`：app.js/api.js/chart.js/market-view.jsすべてPASS。
- `node tests/test_api_js.mjs`：10項目PASS。
- Uvicorn起動、/healthのblock=2・schema_version=2、実ブラウザからAPI読取/保存：PASS。

## ブラウザ操作

| 操作 | 結果 |
|---|---|
| HOME | 架空8銘柄・基準日・取得情報・チャート表示 |
| 銘柄一覧更新 | 保存成功表示、8件の一覧を取得日時付きで表示 |
| DMY004検索 | 1件へ絞込、詳細ボタンで該当銘柄へ遷移 |
| 日足→週足 | 160日足から32週足へ切替、週足表示を確認 |
| 調整切替 | 調整済み/未調整の選択と注意表示が切り替わる |
| 価格更新 | 実APIリクエスト経路からDummy取得・DB保存・再表示 |
| J-Quants選択 | 設定保存、キー未設定を明示。保存銘柄0でもHOMEが停止しない |
| キーなし一覧更新 | HTTP 503/NOT_CONFIGUREDを明示。継続操作とDummy復帰が可能 |
| 提供元復帰 | Dummyへ戻すと8銘柄表示、元watchlist3件を保持 |
| 390px HOME | 検索フォームと更新ボタン、下部ナビの配置を確認 |
| 390px DETAIL | 週足操作、価格調整/更新コントロール、ローソク足を視認 |
| 390px SETTINGS | Provider選択を含む1列フォームを確認 |

HOME/DETAIL/SETTINGSはclientWidthとscrollWidthが375pxで一致し、ページの横はみ出しがないことを確認しました。
390pxのiframeに縦スクロールバーを含むため、DOMの有効幅は375pxです。
キー未設定の意図した503はブラウザのネットワークエラーとして記録され得ます。未処理例外とは区別しています。

## 梱包検証

ZIPのCRC・SHA256・必須ファイル・すべてのDB/backup/秘密.env/実行ログの除外を検証します。
展開先から、preview用依存や元プロジェクトのPYTHONPATHに依存せずテストを再実行した記録をPACKAGE_CHECK.txtへ保存します。

## GitHub向け追加検証

- 既存58件に加え、相対パス・Pages artifactの限定・秘密値非混入・公開ZIP・監査・workflow範囲等を検証し、Pythonは63件。
- Nodeはデモの架空表示、watchの追加/削除/重複防止/再起動保持、テーマ保存、不正設定拒否、日足/週足、検索、保存失敗、外部Backend通信と失敗時の非フォールバックを検証。
- 実ブラウザで`/stock-edge-intelligence/`というリポジトリ名付きパスを使用し、LOCAL DEMO、チャート、5画面、watch保存とリロード後保持、テーマ保存を確認。
- ブラウザ内モードでSQLite接続済みと誤表示せず、Browser storageと実株価API未接続を表示。
- DB初回生成とv1→v2移行の回帰テストは維持。SQL fixtureは旧版の架空データのみ。
- CI/Pages workflowは作成・構文確認のみ。実GitHubリポジトリでのActions実行、Pages公開は未実施。

## 既知の制限

- 実APIキー接続・提供元実値照合は未検証。APIのプラン/権限/実データ差異は利用環境での確認が必要。
- Windows/macOS/Android実機は未検証。BackendのJSTは固定UTC+9とし、Windowsのtzdata依存を避けています。
- Starlette TestClientのhttpx非推奨警告1件。テストはPASSし、通常のUvicorn配信とは別です。
- npmの実行環境http-proxy警告はアプリ構文エラーではありません。
- レート/更新lockは単一プロセス内。複数workers/複数サーバーでの共有制御は未実装。
- 取引所カレンダーによる週足の厳密な完全性判定は未実装。
- 分析・予測・PWA・公開運用の検証は対象外。

BLOCK 3以降を実装していません。
