"""Fetching, atomic cache persistence, fallback, and weekly OHLCV aggregation."""
import logging
import os
import threading
import unicodedata
from datetime import date, datetime, timedelta, timezone

from .market_models import DisplayCandle, Instrument, PriceSeries
from .providers import DummyProvider, JQuantsProvider, JST, MarketDataProvider, ProviderError, normalize_ticker


def weekly_candles(daily, today: date):
    groups={}
    for bar in daily:
        monday=bar.time-timedelta(days=bar.time.weekday())
        groups.setdefault(monday,[]).append(bar)
    result=[]
    keys=sorted(groups)
    current_monday=today-timedelta(days=today.weekday())
    for index,monday in enumerate(keys):
        rows=groups[monday]
        # Boundary flags are conservative: no exchange holiday calendar is inferred.
        partial=(monday>=current_monday or (index==0 and rows[0].time>monday) or
                 (index==len(keys)-1 and rows[-1].time<monday+timedelta(days=4)))
        result.append(DisplayCandle(time=monday,end_date=rows[-1].time,open=rows[0].open,
            high=max(b.high for b in rows),low=min(b.low for b in rows),close=rows[-1].close,
            volume=sum(b.volume for b in rows),observed_sessions=len(rows),is_partial=partial))
    return result


class MarketDataService:
    def __init__(self, repository, providers: dict[str, MarketDataProvider] | None = None, now=None):
        self.repo=repository
        self.providers=providers or {"dummy":DummyProvider(),"jquants":JQuantsProvider()}
        self.now=now or (lambda:datetime.now(timezone.utc))
        self.ttl=max(60,int(os.getenv("STOCK_EDGE_CACHE_TTL_SECONDS","86400")))
        self.logger=logging.getLogger("stock_edge")
        self._lock_guard=threading.Lock()
        self._locks={}

    def active(self):
        return self.repo.get_settings().market_data_provider

    def status(self):
        active=self.active()
        return {"selected":active,"providers":[p.status() for p in self.providers.values()],
                "cache_ttl_seconds":self.ttl,"history_window_calendar_days":550}

    def present_stock(self, stock):
        provider="dummy" if stock.is_dummy else "jquants"
        meta=self.repo.get_cache(provider+":"+stock.ticker) or {}
        change=stock.change_pct
        if not stock.is_dummy and self.repo.price_count(stock.ticker)<2:
            change=None
        return stock.model_copy(update={"provider_id":provider,"data_as_of":date.fromisoformat(
            meta.get("data_as_of") or stock.updated_at.date().isoformat()),"fetched_at":
            datetime.fromisoformat(meta["fetched_at"]) if meta.get("fetched_at") else None,"change_pct":change})

    def stocks(self):
        provider=self.active()
        return [self.present_stock(s) for s in self.repo.list_stocks() if ("dummy" if s.is_dummy else "jquants")==provider]

    def _cache_info(self, resource, has_data):
        meta=self.repo.get_cache(resource) or {}
        fetched=datetime.fromisoformat(meta["fetched_at"]) if meta.get("fetched_at") else None
        age=max(0,(self.now()-fetched).total_seconds()) if fetched else None
        status="stale_error" if meta.get("error_code") else "seed" if has_data and not fetched else "empty" if not has_data else "stale" if age>=self.ttl else "fresh"
        return {"fetched_at":fetched,"data_as_of":meta.get("data_as_of"),"cache_age_seconds":age,
                "cache_status":status,"last_attempt_at":meta.get("last_attempt_at"),
                "error_code":meta.get("error_code"),"error_message":meta.get("error_message"),
                "skipped_rows":meta.get("skipped_rows",0)}

    def search(self, query="",limit=30):
        provider=self.active()
        catalog=self.repo.catalog(provider)
        q=unicodedata.normalize("NFKC",query).strip().casefold()
        try:
            canonical=normalize_ticker(query)
        except ValueError:
            canonical=None
        matches=[i for i in catalog if not q or i.ticker==canonical or q in
                 f"{i.ticker} {i.company} {i.company_en} {i.sector}".casefold()]
        saved={s.ticker for s in self.repo.list_stocks()}
        info=self._cache_info(provider+":catalog",bool(catalog))
        return {"provider_id":provider,"total_catalog":len(catalog),"total_matches":len(matches),
                "items":[{**i.model_dump(mode="json"),"imported":i.ticker in saved} for i in matches[:limit]],
                **info,"provider":self.providers[provider].status()}

    def _claim_update(self,resource):
        with self._lock_guard:
            lock=self._locks.setdefault(resource,threading.Lock())
        if not lock.acquire(blocking=False):
            raise ProviderError("BUSY",1)
        return lock

    def refresh_catalog(self):
        provider_id=self.active(); provider=self.providers[provider_id]
        resource=provider_id+":catalog"
        lock=None
        try:
            lock=self._claim_update(resource)
            items=provider.fetch_catalog()
            if not items:
                raise ProviderError("EMPTY")
            if any(i.provider_id!=provider_id or i.is_dummy!=provider.is_dummy for i in items):
                raise ProviderError("INVALID_DATA")
            self.repo.save_catalog(provider_id,items,self.now().isoformat())
            self.logger.info("Catalog refreshed provider=%s rows=%d",provider_id,len(items))
        except ProviderError as exc:
            self.repo.mark_failure(resource,provider_id,self.now().isoformat(),exc.code,exc.message)
            self.logger.warning("Catalog refresh failed provider=%s code=%s",provider_id,exc.code)
            if not self.repo.catalog(provider_id):
                raise
        finally:
            if lock:
                lock.release()
        return self.search()

    def get_prices(self,ticker,interval="1d",basis="adjusted",force=False):
        stock=self.repo.get_stock(ticker)
        if stock:
            provider_id="dummy" if stock.is_dummy else "jquants"
        else:
            provider_id=self.active()
        provider=self.providers[provider_id]
        resource=provider_id+":"+ticker
        info=self._cache_info(resource,bool(stock))
        failed_recently=info["error_code"] and info["last_attempt_at"] and (
            self.now()-datetime.fromisoformat(info["last_attempt_at"])).total_seconds()<60
        needs_refresh=force or not stock or (info["cache_status"] in {"seed","stale","stale_error"} and not failed_recently)
        retry=None
        if needs_refresh:
            lock=None
            try:
                lock=self._claim_update(resource)
                instruments=self.repo.catalog(provider_id)
                instrument=next((i for i in instruments if i.ticker==ticker),None)
                if not instrument and stock:
                    instrument=Instrument(ticker=stock.ticker,company=stock.company,sector=stock.sector,
                        exchange=stock.exchange,provider_id=provider_id,is_dummy=stock.is_dummy,
                        snapshot_date=stock.updated_at.date())
                if not instrument:
                    raise ProviderError("NOT_FOUND")
                bars,skipped=provider.fetch_daily(instrument)
                if not bars:
                    raise ProviderError("EMPTY")
                if any(b.time>=bars[i+1].time for i,b in enumerate(bars[:-1])):
                    raise ProviderError("INVALID_DATA")
                self.repo.save_prices(instrument,bars,self.now().isoformat(),provider.source,skipped)
                self.logger.info("Prices refreshed provider=%s ticker=%s rows=%d skipped=%d",provider_id,ticker,len(bars),skipped)
            except ProviderError as exc:
                retry=exc.retry_after
                self.repo.mark_failure(resource,provider_id,self.now().isoformat(),exc.code,exc.message)
                self.logger.warning("Price refresh failed provider=%s ticker=%s code=%s",provider_id,ticker,exc.code)
                if not stock:
                    raise
            finally:
                if lock:
                    lock.release()
        stock=self.present_stock(self.repo.get_stock(ticker))
        daily=[b.candle(basis) for b in self.repo.daily_prices(ticker)]
        if not daily:
            raise ProviderError("EMPTY")
        info=self._cache_info(resource,True)
        warnings=[]
        if stock.is_dummy:
            warnings.append("固定の架空OHLCVです。取得日時が新しくても実際の株価ではありません。")
        elif provider.status()["delay_days"]:
            warnings.append("Freeプランは12週間遅延です。最新株価ではありません。")
        if not stock.is_dummy:
            warnings.append("銘柄価格は未調整終値。騰落率は前観測日の調整済終値比です。")
        warnings.append("調整済み価格・出来高（配当未調整）。過去値は遡及修正されます。" if basis=="adjusted" else
                        "未調整価格・出来高。分割等で不連続になる場合があります。")
        candles=[DisplayCandle(**b.model_dump()) for b in daily]
        if interval=="1wk":
            candles=weekly_candles(daily,self.now().astimezone(JST).date())
            warnings.append("月曜始まりの観測日足集計。進行週・境界週は未確定の可能性があります。休場日を補完しません。")
        return PriceSeries(ticker=ticker,interval=interval,basis=basis,source=stock.source,
            provider_id=provider_id,is_dummy=stock.is_dummy,updated_at=stock.updated_at,
            data_as_of=stock.data_as_of,**{k:v for k,v in info.items() if k!="data_as_of"},
            retry_after=retry,warnings=warnings,candles=candles,stock=stock)

    def close(self):
        for provider in self.providers.values():
            provider.close()
