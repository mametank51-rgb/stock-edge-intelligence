import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")


def resolve_path(value: str) -> Path:
    path = Path(value).expanduser()
    return path if path.is_absolute() else ROOT / path


DB_PATH = resolve_path(os.getenv("STOCK_EDGE_DB", "database/stock_edge.db"))
LOG_DIR = resolve_path(os.getenv("STOCK_EDGE_LOG_DIR", "logs"))
CORS_ORIGINS = [origin.strip() for origin in os.getenv(
    "STOCK_EDGE_CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173"
).split(",") if origin.strip()]
VERSION = "0.2.1"
