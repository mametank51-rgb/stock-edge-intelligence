"""Provider seam and documented J-Quants V2 adapter. Secrets stay server-side."""
import math
import os
import re
import threading
import time
import unicodedata
from collections import deque
from datetime import date, datetime, timedelta, timezone
from typing import Protocol

import httpx
from pydantic import ValidationError

from .market_models import DailyPrice, Instrument
from .seed import fixtures

# Japan has no DST in the supported 2008+ history; works on Windows without tzdata.
JST = timezone(timedelta(hours=9),"Asia/Tokyo")
ERROR_MESSAGES = {
    "NOT_CONFIGURED": "JQUANTS_API_KEYがBackendに設定されていません。",
    "AUTH": "提供元の認証または契約範囲を確認してください。",
    "RATE_LIMIT": "提供元の呼出し上限です。時間を置いて再試行してください。",
    "TIMEOUT": "提供元への接続がタイムアウトしました。",
    "NETWORK": "提供元へ接続できません。",
    "UPSTREAM": "提供元がエラーを返しました。",
    "INVALID_DATA": "提供元のデータ形式またはOHLCV整合性が不正です。",
    "EMPTY": "対象期間に利用可能な価格データがありません。",
    "PAGINATION": "取得ページの上限または重複を検出しました。再試行してください。",
    "BUSY": "別のデータ更新を実行中です。少し待って再試行してください。",
    "NOT_FOUND": "銘柄一覧にコードがありません。銘柄一覧を更新して確認してください。",
}


class ProviderError(Exception):
    def __init__(self, code, retry_after=None):
        self.code = code
        self.retry_after = retry_after
        self.message = ERROR_MESSAGES[code]
        super().__init__(self.message)


def normalize_ticker(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).strip().upper()
    if re.fullmatch(r"DMY\d{3}", value):
        return value
    if value.endswith(".T"):
        value = value[:-2]
    if not re.fullmatch(r"[0-9][0-9A-Z]{3,4}", value):
        raise ValueError("日本株コードは4〜5桁の英数字で指定してください。")
    return value+"0" if len(value) == 4 else value


class MarketDataProvider(Protocol):
    provider_id: str
    source: str
    is_dummy: bool
    def status(self) -> dict: ...
    def fetch_catalog(self) -> list[Instrument]: ...
    def fetch_daily(self, instrument: Instrument) -> tuple[list[DailyPrice], int]: ...
    def close(self) -> None: ...


class DummyProvider:
    provider_id = "dummy"
    source = "BLOCK1_SYNTHETIC"
    is_dummy = True

    def status(self):
        return {"id":self.provider_id,"name":"DummyProvider","configured":True,"is_dummy":True,
                "plan":None,"delay_days":None,"message":"固定の架空データ。更新しても最新株価にはなりません。"}

    def fetch_catalog(self):
        stocks,_ = fixtures()
        return [Instrument(ticker=s.ticker,company=s.company,sector=s.sector,exchange=s.exchange,
                           provider_id="dummy",is_dummy=True,snapshot_date=s.updated_at.date()) for s in stocks]

    def fetch_daily(self, instrument):
        _,history=fixtures()
        if instrument.ticker not in history:
            raise ProviderError("NOT_FOUND")
        return [DailyPrice(**c.model_dump(),**{"adjusted_"+k:getattr(c,k) for k in
                ("open","high","low","close","volume")}) for c in history[instrument.ticker]],0

    def close(self):
        pass


class JQuantsProvider:
    provider_id = "jquants"
    source = "JQUANTS_V2"
    is_dummy = False
    BASE = "https://api.jquants.com/v2"

    def __init__(self, api_key=None, plan=None, client=None, today=None, clock=None):
        self._key = api_key if api_key is not None else os.getenv("JQUANTS_API_KEY", "")
        self.plan = plan or os.getenv("JQUANTS_PLAN", "free").lower()
        if self.plan not in {"free","light","standard","premium"}:
            raise ValueError("JQUANTS_PLAN must be free/light/standard/premium")
        self._client = client
        self._today = today or (lambda:datetime.now(JST).date())
        self._clock = clock or time.monotonic
        self._calls = deque()
        self._rate_lock = threading.Lock()
        self._cooldown_until = 0
        self.limit = {"free":5,"light":60,"standard":120,"premium":500}[self.plan]

    def status(self):
        return {"id":self.provider_id,"name":"J-Quants V2","configured":bool(self._key),
                "is_dummy":False,"plan":self.plan,"delay_days":84 if self.plan=="free" else 0,
                "message":"Freeは12週間遅延。日足の基準日を確認してください。" if self.plan=="free" else
                "日次データ。リアルタイム配信ではありません。"}

    def end_date(self):
        return self._today()-timedelta(days=84 if self.plan=="free" else 0)

    def _claim(self):
        with self._rate_lock:
            now=self._clock()
            while self._calls and self._calls[0] <= now-60:
                self._calls.popleft()
            if now < self._cooldown_until:
                raise ProviderError("RATE_LIMIT", max(1,math.ceil(self._cooldown_until-now)))
            if len(self._calls) >= self.limit:
                raise ProviderError("RATE_LIMIT", max(1,math.ceil(60-(now-self._calls[0]))))
            self._calls.append(now)

    def _pages(self, endpoint, params):
        if not self._key:
            raise ProviderError("NOT_CONFIGURED")
        if self._client is None:
            self._client=httpx.Client(follow_redirects=False)
        rows, seen = [],set()
        deadline=self._clock()+6.5
        params=dict(params)
        for _ in range(10):
            payload=None
            for attempt in range(2):
                if self._clock() >= deadline:
                    raise ProviderError("TIMEOUT")
                self._claim()
                try:
                    response=self._client.get(self.BASE+endpoint,params=params,
                        headers={"x-api-key":self._key},timeout=min(2.5, max(.1,deadline-self._clock())))
                except httpx.TimeoutException:
                    if attempt == 0:
                        continue
                    raise ProviderError("TIMEOUT") from None
                except httpx.RequestError:
                    if attempt == 0:
                        continue
                    raise ProviderError("NETWORK") from None
                if response.status_code in (401,403):
                    raise ProviderError("AUTH")
                if response.status_code == 429:
                    raw=response.headers.get("Retry-After", "60")
                    retry=min(3600,max(1,int(raw))) if raw.isdigit() else 60
                    with self._rate_lock:
                        self._cooldown_until=self._clock()+retry
                    raise ProviderError("RATE_LIMIT",retry)
                if response.status_code >= 500 and attempt == 0:
                    continue
                if response.status_code != 200:
                    raise ProviderError("UPSTREAM")
                try:
                    payload=response.json()
                except ValueError:
                    raise ProviderError("INVALID_DATA") from None
                break
            if not isinstance(payload,dict) or not isinstance(payload.get("data"),list):
                raise ProviderError("INVALID_DATA")
            if any(not isinstance(row,dict) for row in payload["data"]):
                raise ProviderError("INVALID_DATA")
            rows.extend(payload["data"])
            cursor=payload.get("pagination_key")
            if not cursor:
                return rows
            if not isinstance(cursor,str) or cursor in seen or len(cursor)>4096:
                raise ProviderError("PAGINATION")
            seen.add(cursor)
            params["pagination_key"]=cursor
        raise ProviderError("PAGINATION")

    def fetch_catalog(self):
        rows=self._pages("/equities/master",{"date":self.end_date().isoformat()})
        instruments={}
        try:
            for row in rows:
                if "ProdCat" not in row:
                    raise ValueError("Missing product category")
                # BLOCK 2 supports domestic equities, including preferred share codes.
                if row["ProdCat"] != "011":
                    continue
                instrument=Instrument(ticker=normalize_ticker(row["Code"]),company=row["CoName"],
                    company_en=row.get("CoNameEn") or "",sector=row.get("S33Nm") or "未分類",
                    exchange="TSE",provider_id="jquants",is_dummy=False,snapshot_date=row["Date"])
                if not instrument.company or instrument.ticker.startswith("DMY") or instrument.snapshot_date>self.end_date():
                    raise ValueError("Invalid catalog identity")
                if instrument.ticker in instruments and instrument != instruments[instrument.ticker]:
                    raise ValueError("Conflicting duplicate")
                instruments[instrument.ticker]=instrument
        except (KeyError,ValueError,TypeError,ValidationError):
            raise ProviderError("INVALID_DATA") from None
        if not instruments:
            raise ProviderError("EMPTY")
        return sorted(instruments.values(),key=lambda i:i.ticker)

    @staticmethod
    def _number(row,key):
        value=row[key]
        if isinstance(value,bool) or not isinstance(value,(float,int)) or not math.isfinite(value):
            raise ValueError("Invalid numeric value")
        return value

    def fetch_daily(self, instrument):
        end=self.end_date(); start=end-timedelta(days=550)
        rows=self._pages("/equities/bars/daily",{"code":instrument.ticker,"from":start.isoformat(),"to":end.isoformat()})
        values,skipped={},0
        raw_keys=("O","H","L","C","Vo")
        adj_keys=("AdjO","AdjH","AdjL","AdjC","AdjVo")
        try:
            for row in rows:
                if normalize_ticker(row["Code"]) != instrument.ticker:
                    raise ValueError("Ticker mismatch")
                day=date.fromisoformat(row["Date"])
                if not start <= day <= end:
                    raise ValueError("Date outside requested window")
                if all(row[k] is None for k in raw_keys+adj_keys):
                    skipped+=1
                    continue  # No executions: do not invent zero bars or fill market holidays.
                raw={k:self._number(row,v) for k,v in zip(("open","high","low","close","volume"),raw_keys)}
                adjusted={"adjusted_"+k:self._number(row,v) for k,v in zip(("open","high","low","close","volume"),adj_keys)}
                bar=DailyPrice(time=day,**raw,**adjusted,adjustment_factor=self._number(row,"AdjFactor"))
                if day in values and values[day]!=bar:
                    raise ValueError("Conflicting duplicate date")
                values[day]=bar
        except (KeyError,ValueError,TypeError,ValidationError):
            raise ProviderError("INVALID_DATA") from None
        if not values:
            raise ProviderError("EMPTY")
        return sorted(values.values(),key=lambda b:b.time),skipped

    def close(self):
        if self._client is not None:
            self._client.close()
            self._client=None
