"""Transport contracts. Future engines have contracts, but no calculations yet."""
from datetime import date, datetime
from enum import Enum
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Score = Annotated[float, Field(ge=0, le=100)]
Horizon = Literal[5, 20, 60]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class Scores(StrictModel):
    technical: Score | None = None
    fundamental: Score | None = None
    intelligence: Score | None = None
    market: Score | None = None
    opportunity: Score | None = None
    risk: Score | None = None
    edge: Score | None = None
    conviction: Score | None = None
    signal_diversity: Score | None = None
    conflict: Score | None = None


class AssetType(str, Enum):
    EQUITY = "EQUITY"
    ETF = "ETF"
    FX = "FX"
    CRYPTO = "CRYPTO"


class Stock(StrictModel):
    ticker: str
    company: str
    sector: str
    market: str = "JP"
    exchange: str = "DEMO"
    asset_type: AssetType = AssetType.EQUITY
    currency: str = "JPY"
    price: float = Field(gt=0)
    change_pct: float | None
    scores: Scores
    source: str = "BLOCK1_SYNTHETIC"
    is_dummy: bool = True
    updated_at: datetime
    provider_id: str = "dummy"
    data_as_of: date | None = None
    fetched_at: datetime | None = None


class Candle(StrictModel):
    time: date
    open: float = Field(gt=0)
    high: float = Field(gt=0)
    low: float = Field(gt=0)
    close: float = Field(gt=0)
    volume: float = Field(ge=0)

    @model_validator(mode="after")
    def price_bounds(self):
        if self.low > min(self.open, self.close) or self.high < max(self.open, self.close):
            raise ValueError("OHLC bounds are inconsistent")
        return self


class WeightSet(StrictModel):
    technical: Score
    fundamental: Score
    intelligence: Score
    market: Score

    @model_validator(mode="after")
    def sum_to_100(self):
        if abs(sum((self.technical, self.fundamental, self.intelligence, self.market)) - 100) > .001:
            raise ValueError("Weights must sum to 100")
        return self


DEFAULT_WEIGHTS = {
    "5": WeightSet(technical=55, fundamental=10, intelligence=20, market=15),
    "20": WeightSet(technical=35, fundamental=30, intelligence=25, market=10),
    "60": WeightSet(technical=20, fundamental=45, intelligence=25, market=10),
}


class AppSettings(StrictModel):
    theme: Literal["dark", "light"] = "dark"
    market: Literal["JP"] = "JP"
    debug_mode: bool = False
    market_data_provider: Literal["dummy", "jquants"] = "dummy"
    weights: dict[str, WeightSet] = Field(default_factory=lambda: dict(DEFAULT_WEIGHTS))

    @field_validator("weights")
    @classmethod
    def all_horizons(cls, value):
        if set(value) != {"5", "20", "60"}:
            raise ValueError("Exactly 5, 20, 60 day horizons are required")
        return value


class SettingsPatch(StrictModel):
    theme: Literal["dark", "light"] | None = None
    market: Literal["JP"] | None = None
    debug_mode: bool | None = None
    market_data_provider: Literal["dummy", "jquants"] | None = None
    weights: dict[str, WeightSet] | None = None

    @model_validator(mode="after")
    def reject_null(self):
        if any(getattr(self, key) is None for key in self.model_fields_set):
            raise ValueError("Explicit null is not supported")
        return self


# Future-only contracts. No provider, scenario, scoring, or history engine exists in BLOCK 1.
class ProviderType(str, Enum):
    AI_SERVICE = "AI_SERVICE"
    ANALYST = "ANALYST"
    SECURITIES_COMPANY = "SECURITIES_COMPANY"
    INVESTOR = "INVESTOR"
    INSIDER = "INSIDER"
    INSTITUTION = "INSTITUTION"
    OPTIONS = "OPTIONS"
    SOCIAL = "SOCIAL"
    ALTERNATIVE_DATA = "ALTERNATIVE_DATA"
    NEWS = "NEWS"


class ProviderContract(StrictModel):
    provider_id: str
    provider_name: str
    provider_type: ProviderType
    source_category: str
    sector_specialty: str | None = None
    country: str | None = None


class ExternalPredictionContract(StrictModel):
    provider_id: str
    ticker: str
    prediction_horizon: Horizon
    direction: Literal["bull", "base", "bear"]
    confidence: Score | None = None
    target_price: float | None = None
    published_at: datetime
    available_at: datetime
    source_url: str | None = None


class ProviderPerformanceContract(StrictModel):
    provider_id: str
    horizon: Horizon
    sector: str
    market_regime: str
    sample_count: int = Field(ge=0)
    historical_accuracy: Score | None = None


class ScenarioContract(StrictModel):
    direction: Literal["bull", "base", "bear"]
    condition: str
    invalidation: str
    targets: list[float]
    probability: Score | None = None


class MarketContextContract(StrictModel):
    observed_at: datetime
    regime: str | None = None
    benchmarks: dict[str, float | None]


class PredictionSnapshotContract(StrictModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    snapshot_id: str
    ticker: str
    captured_at: datetime
    price: float
    horizon: Horizon
    scores: Scores
    scenarios: tuple[ScenarioContract, ...]
    model_version: str
    data_version: str
