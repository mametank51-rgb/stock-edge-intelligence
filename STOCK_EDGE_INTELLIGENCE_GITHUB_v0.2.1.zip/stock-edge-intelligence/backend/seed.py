"""Deterministic fictional fixtures only. NOT prices of listed companies."""
import math
import random
from datetime import date, timedelta

from .models import Candle, Scores, Stock

AS_OF = "2026-10-23T06:00:00+00:00"
DEMO_COMPANIES = [
    ("DMY001", "青凪テクノロジー", "半導体・電子", 3180, 86, 34),
    ("DMY002", "翠光エネルギー", "エネルギー", 2460, 81, 29),
    ("DMY003", "星原マテリアル", "素材", 1742, 78, 41),
    ("DMY004", "北辰ロボティクス", "機械", 5230, 75, 48),
    ("DMY005", "澄海ファイナンス", "金融", 1285, 72, 32),
    ("DMY006", "白峰ヘルスケア", "ヘルスケア", 3870, 69, 37),
    ("DMY007", "日和リテール", "小売", 862, 65, 44),
    ("DMY008", "東雲モビリティ", "輸送用機器", 2185, 61, 57),
]


def fixtures():
    days = []
    day = date(2026, 10, 23)
    while len(days) < 160:
        if day.weekday() < 5:
            days.append(day)
        day -= timedelta(days=1)
    days.reverse()  # Weekdays only; not an exchange holiday calendar.
    stocks, histories = [], {}
    for index, (ticker, company, sector, final, edge, risk) in enumerate(DEMO_COMPANIES):
        rng = random.Random(8021 + index)
        values, previous = [], final * .78
        for n, day in enumerate(days):
            opening = previous * (1 + rng.uniform(-.008, .008))
            close = max(20, opening * (1 + .0012 + .003 * math.sin(n / 11) + rng.uniform(-.018, .018)))
            high = max(opening, close) * (1 + rng.uniform(.002, .018))
            low = min(opening, close) * (1 - rng.uniform(.002, .018))
            values.append([day, opening, high, low, close, rng.randint(180000, 1900000)])
            previous = close
        scale = final / values[-1][4]
        candles = [Candle(time=r[0], open=round(r[1]*scale, 2), high=round(r[2]*scale, 2),
                          low=round(r[3]*scale, 2), close=round(r[4]*scale, 2), volume=r[5]) for r in values]
        change = round((candles[-1].close / candles[-2].close - 1) * 100, 2)
        # Fixture values are independent constants; no scoring/Meta Edge engine.
        scores = Scores(technical=88-index*4, fundamental=79-index*3,
                        intelligence=82-index*2, market=68, edge=edge, risk=risk,
                        opportunity=90-index*4, conviction=80-index*3,
                        signal_diversity=74-index*2, conflict=12+index*4)
        stocks.append(Stock(ticker=ticker, company=company+"（架空）", sector=sector,
                            price=final, change_pct=change, scores=scores, updated_at=AS_OF))
        histories[ticker] = candles
    return stocks, histories
