"""SQL lives here, behind a Protocol seam for a future PostgreSQL repository."""
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Protocol

from .config import ROOT
from .models import AppSettings, Candle, Stock
from .seed import fixtures
from .market_models import DailyPrice, Instrument


class StockRepository(Protocol):
    def initialize(self) -> None: ...
    def health(self) -> dict: ...
    def list_stocks(self) -> list[Stock]: ...
    def get_stock(self, ticker: str) -> Stock | None: ...
    def prices(self, ticker: str) -> list[Candle]: ...
    def price_count(self, ticker: str) -> int: ...
    def list_watchlist(self) -> list[Stock]: ...
    def add_watchlist(self, ticker: str) -> None: ...
    def remove_watchlist(self, ticker: str) -> None: ...
    def get_settings(self) -> AppSettings: ...
    def update_settings(self, patch: dict) -> AppSettings: ...
    def get_cache(self, resource: str) -> dict | None: ...
    def mark_failure(self, resource: str, provider: str, attempted: str, code: str, message: str) -> None: ...
    def catalog(self, provider: str) -> list[Instrument]: ...
    def save_catalog(self, provider: str, items: list[Instrument], fetched: str) -> None: ...
    def daily_prices(self, ticker: str) -> list[DailyPrice]: ...
    def save_prices(self, instrument: Instrument, bars: list[DailyPrice], fetched: str, source: str, skipped: int) -> None: ...


class SQLiteRepository:
    def __init__(self, path: Path):
        self.path = path

    @contextmanager
    def connection(self):
        conn = sqlite3.connect(self.path, timeout=5)
        try:
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys=ON")
            with conn:
                yield conn
        finally:
            conn.close()

    def initialize(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as conn:
            version = conn.execute("PRAGMA user_version").fetchone()[0]
            if version > 2:
                raise RuntimeError("Database schema is newer than this application")
            conn.execute("PRAGMA journal_mode=WAL")
            if version == 0:
                conn.executescript((ROOT / "database/schema.sql").read_text(encoding="utf-8"))
            if version < 2:
                self._seed_if_needed(conn)
                conn.commit()
                if version == 1:
                    backup_dir = self.path.parent / "backups"
                    backup_dir.mkdir(parents=True, exist_ok=True)
                    backup_path = backup_dir / (self.path.name+".v1.bak")
                    if not backup_path.exists():
                        target = sqlite3.connect(backup_path)
                        try:
                            conn.backup(target)
                        finally:
                            target.close()
                migration = (ROOT / "database/migrations/002_market_data.sql").read_text(encoding="utf-8")
                try:
                    conn.executescript("BEGIN IMMEDIATE;\n"+migration+"\nCOMMIT;")
                except Exception:
                    if conn.in_transaction:
                        conn.rollback()
                    raise

    def _seed_if_needed(self, conn):
        conn.execute("BEGIN IMMEDIATE")
        if conn.execute("SELECT 1 FROM settings WHERE key='seed_version'").fetchone():
            return
        stocks, histories = fixtures()
        for stock in stocks:
            data = stock.model_dump(mode="json")
            conn.execute("INSERT INTO stocks VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                stock.ticker, stock.company, stock.sector, stock.market, stock.exchange,
                stock.asset_type.value, stock.currency, stock.price, stock.change_pct,
                json.dumps(data["scores"]), stock.source, int(stock.is_dummy), data["updated_at"]))
            conn.executemany("INSERT INTO price_history VALUES(?,?,?,?,?,?,?)", [
                (stock.ticker, c.time.isoformat(), c.open, c.high, c.low, c.close, c.volume)
                for c in histories[stock.ticker]])
        now = datetime.now(timezone.utc).isoformat()
        conn.executemany("INSERT INTO watchlist VALUES(?,?)", [(s.ticker, now) for s in stocks[:3]])
        conn.execute("INSERT INTO settings VALUES('app',?)", (AppSettings().model_dump_json(),))
        conn.execute("INSERT INTO settings VALUES('seed_version','1')")

    @staticmethod
    def stock(row) -> Stock:
        data = dict(row)
        data["scores"] = json.loads(data.pop("scores_json"))
        data["provider_id"] = "dummy" if data["is_dummy"] else "jquants"
        data["data_as_of"] = data["updated_at"][:10]
        return Stock.model_validate(data)

    def health(self):
        with self.connection() as conn:
            conn.execute("SELECT 1").fetchone()
            return {"status": "ok", "schema_version": conn.execute("PRAGMA user_version").fetchone()[0],
                    "stock_count": conn.execute("SELECT count(*) FROM stocks").fetchone()[0]}

    def list_stocks(self):
        with self.connection() as conn:
            return [self.stock(row) for row in conn.execute("SELECT * FROM stocks ORDER BY ticker")]

    def get_stock(self, ticker):
        with self.connection() as conn:
            row = conn.execute("SELECT * FROM stocks WHERE ticker=?", (ticker,)).fetchone()
            return self.stock(row) if row else None

    def prices(self, ticker):
        with self.connection() as conn:
            return [Candle(time=row["date"], **{k: row[k] for k in ("open", "high", "low", "close", "volume")})
                    for row in conn.execute("SELECT * FROM price_history WHERE ticker=? ORDER BY date", (ticker,))]

    def price_count(self,ticker):
        with self.connection() as conn:
            return conn.execute("SELECT count(*) FROM price_history WHERE ticker=?",(ticker,)).fetchone()[0]

    def list_watchlist(self):
        with self.connection() as conn:
            return [self.stock(row) for row in conn.execute(
                "SELECT s.* FROM stocks s JOIN watchlist w ON s.ticker=w.ticker ORDER BY w.created_at,s.ticker")]

    def add_watchlist(self, ticker):
        with self.connection() as conn:
            conn.execute("INSERT OR IGNORE INTO watchlist VALUES(?,?)", (ticker, datetime.now(timezone.utc).isoformat()))

    def remove_watchlist(self, ticker):
        with self.connection() as conn:
            conn.execute("DELETE FROM watchlist WHERE ticker=?", (ticker,))

    def get_settings(self):
        with self.connection() as conn:
            row = conn.execute("SELECT value FROM settings WHERE key='app'").fetchone()
            return AppSettings.model_validate_json(row[0])

    def update_settings(self, patch):
        with self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            current = json.loads(conn.execute("SELECT value FROM settings WHERE key='app'").fetchone()[0])
            updated = AppSettings.model_validate({**current, **patch})
            conn.execute("UPDATE settings SET value=? WHERE key='app'", (updated.model_dump_json(),))
            return updated

    def get_cache(self, resource):
        with self.connection() as conn:
            row = conn.execute("SELECT * FROM data_cache WHERE resource=?", (resource,)).fetchone()
            return dict(row) if row else None

    @staticmethod
    def _cache_success(conn, resource, provider, fetched, as_of, skipped=0):
        conn.execute("""INSERT INTO data_cache VALUES(?,?,?,?,?,NULL,NULL,?)
            ON CONFLICT(resource) DO UPDATE SET fetched_at=excluded.fetched_at,
            data_as_of=excluded.data_as_of,last_attempt_at=excluded.last_attempt_at,
            error_code=NULL,error_message=NULL,skipped_rows=excluded.skipped_rows""",
            (resource,provider,fetched,as_of,fetched,skipped))

    def mark_failure(self, resource, provider, attempted, code, message):
        with self.connection() as conn:
            conn.execute("""INSERT INTO data_cache(resource,provider_id,last_attempt_at,error_code,error_message)
                VALUES(?,?,?,?,?) ON CONFLICT(resource) DO UPDATE SET
                last_attempt_at=excluded.last_attempt_at,error_code=excluded.error_code,error_message=excluded.error_message""",
                (resource,provider,attempted,code,message))

    def catalog(self, provider):
        with self.connection() as conn:
            return [Instrument.model_validate(dict(row)) for row in conn.execute(
                "SELECT * FROM instruments WHERE provider_id=? ORDER BY ticker", (provider,))]

    def save_catalog(self, provider, items, fetched):
        with self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute("DELETE FROM instruments WHERE provider_id=?", (provider,))
            conn.executemany("INSERT INTO instruments VALUES(?,?,?,?,?,?,?,?,?,?)", [
                (i.provider_id,i.ticker,i.company,i.company_en,i.sector,i.exchange,i.market,i.currency,
                 int(i.is_dummy),i.snapshot_date.isoformat()) for i in items])
            self._cache_success(conn,provider+":catalog",provider,fetched,
                                max(i.snapshot_date for i in items).isoformat())

    def daily_prices(self, ticker):
        with self.connection() as conn:
            rows=conn.execute("""SELECT p.*,a.adjusted_open,a.adjusted_high,a.adjusted_low,
                a.adjusted_close,a.adjusted_volume,a.adjustment_factor
                FROM price_history p JOIN price_adjustments a USING(ticker,date)
                WHERE p.ticker=? ORDER BY p.date""", (ticker,))
            return [DailyPrice(time=r["date"], **{k:r[k] for k in (
                "open","high","low","close","volume","adjusted_open","adjusted_high",
                "adjusted_low","adjusted_close","adjusted_volume","adjustment_factor")}) for r in rows]

    def save_prices(self, instrument, bars, fetched, source, skipped=0):
        from .models import Scores
        last=bars[-1]
        change=round((last.adjusted_close/bars[-2].adjusted_close-1)*100,2) if len(bars)>1 else None
        existing=self.get_stock(instrument.ticker)
        # Keep original fixture scores unchanged; real instruments have no calculated scores.
        score_json=(existing.scores if instrument.is_dummy and existing else Scores()).model_dump_json()
        updated=(existing.updated_at.isoformat() if instrument.is_dummy and existing else
                 last.time.isoformat()+"T00:00:00+09:00")
        with self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            # Legacy change_pct is NOT NULL: single-bar change is represented by 0 in storage,
            # and exposed as null by the market service when fewer than two bars exist.
            conn.execute("""INSERT INTO stocks VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(ticker) DO UPDATE SET company=excluded.company,sector=excluded.sector,
                price=excluded.price,change_pct=excluded.change_pct,scores_json=excluded.scores_json,
                source=excluded.source,updated_at=excluded.updated_at""", (
                instrument.ticker,instrument.company,instrument.sector,instrument.market,instrument.exchange,
                "EQUITY",instrument.currency,last.close,change if change is not None else 0,
                score_json,source,int(instrument.is_dummy),updated))
            # Full bounded-window replacement prevents mixing differently adjusted histories.
            conn.execute("DELETE FROM price_history WHERE ticker=?", (instrument.ticker,))
            conn.executemany("INSERT INTO price_history VALUES(?,?,?,?,?,?,?)", [
                (instrument.ticker,b.time.isoformat(),b.open,b.high,b.low,b.close,b.volume) for b in bars])
            conn.executemany("INSERT INTO price_adjustments VALUES(?,?,?,?,?,?,?,?)", [
                (instrument.ticker,b.time.isoformat(),b.adjusted_open,b.adjusted_high,b.adjusted_low,
                 b.adjusted_close,b.adjusted_volume,b.adjustment_factor) for b in bars])
            self._cache_success(conn,instrument.provider_id+":"+instrument.ticker,instrument.provider_id,
                                fetched,last.time.isoformat(),skipped)
