import logging
import sqlite3
from contextlib import asynccontextmanager
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import ValidationError

from .config import CORS_ORIGINS, DB_PATH, LOG_DIR, ROOT, VERSION
from .models import AppSettings, SettingsPatch, Stock
from .repository import SQLiteRepository, StockRepository
from .market_data import MarketDataService
from .providers import ProviderError, normalize_ticker


def create_app(db_path: Path | None = None, repository: StockRepository | None = None, providers=None, now=None):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("stock_edge")
    if not logger.handlers:
        handler = RotatingFileHandler(LOG_DIR / "app.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    repo = repository or SQLiteRepository(db_path or DB_PATH)
    market = MarketDataService(repo,providers=providers,now=now)

    @asynccontextmanager
    async def lifespan(app):
        try:
            repo.initialize()
            logger.info("BLOCK 2 started; market data provider configured in settings")
        except Exception:
            logger.exception("Database initialization failed")
            raise
        try:
            yield
        finally:
            market.close()

    app = FastAPI(title="STOCK EDGE INTELLIGENCE", version=VERSION, lifespan=lifespan)
    app.state.repository = repo
    app.state.market = market
    app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS,
                       allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"], allow_headers=["Content-Type"])

    @app.middleware("http")
    async def response_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.exception_handler(sqlite3.Error)
    async def database_error(request, exc):
        logger.error("Database operation failed: %s", type(exc).__name__)
        return JSONResponse(status_code=503, content={"detail": "DBに接続できません。再試行してください。"})

    @app.exception_handler(ProviderError)
    async def provider_error(request,exc):
        status=429 if exc.code=="RATE_LIMIT" else 409 if exc.code=="BUSY" else 404 if exc.code=="NOT_FOUND" else 503
        headers={"Retry-After":str(exc.retry_after)} if exc.retry_after else {}
        return JSONResponse(status_code=status,headers=headers,content={"detail":exc.message,
            "error_code":exc.code,"retry_after":exc.retry_after})

    @app.exception_handler(Exception)
    async def unexpected_error(request, exc):
        logger.exception("Unhandled server error")
        return JSONResponse(status_code=500, content={"detail": "サーバーでエラーが発生しました。ログを確認してください。"})

    def require_stock(ticker):
        try:
            ticker=normalize_ticker(ticker)
        except ValueError:
            pass
        stock = repo.get_stock(ticker)
        if stock is None:
            raise HTTPException(404, "保存済み銘柄が見つかりません。銘柄検索から価格を取得してください。")
        return market.present_stock(stock)

    @app.get("/health")
    def health():
        stocks=market.stocks()
        selected=market.active()
        return {"status": "ok", "version": VERSION, "block": 2, "mode": selected,
                "database": repo.health(), "source":market.providers[selected].source,
                "data_as_of":max((s.data_as_of for s in stocks),default=None)}

    @app.get("/stocks", response_model=list[Stock])
    def stocks():
        return market.stocks()

    @app.get("/stocks/{ticker}", response_model=Stock)
    def stock(ticker: str):
        return require_stock(ticker)

    @app.get("/stocks/{ticker}/prices")
    def prices(ticker: str,interval:Literal["1d","1wk"]="1d",basis:Literal["raw","adjusted"]="adjusted"):
        stock=require_stock(ticker)
        return market.get_prices(stock.ticker,interval,basis)

    @app.post("/stocks/{ticker}/refresh")
    def refresh_prices(ticker: str,interval:Literal["1d","1wk"]="1d",basis:Literal["raw","adjusted"]="adjusted"):
        try:
            ticker=normalize_ticker(ticker)
        except ValueError as exc:
            raise HTTPException(422,str(exc)) from None
        return market.get_prices(ticker,interval,basis,force=True)

    @app.get("/market/providers")
    def providers_status():
        return market.status()

    @app.get("/market/search")
    def market_search(q:str="",limit:int=30):
        if len(q)>120 or not 1<=limit<=100:
            raise HTTPException(422,"検索語は120文字以内、件数は1〜100で指定してください。")
        return market.search(q,limit)

    @app.post("/market/catalog/refresh")
    def refresh_catalog():
        return market.refresh_catalog()

    @app.get("/ranking", response_model=list[Stock])
    def ranking():
        # Sorting fixed seed values only, not analysis or a calculated ranking engine.
        return sorted(market.stocks(), key=lambda s: (s.scores.edge is None,-(s.scores.edge or 0),s.ticker))

    @app.get("/watchlist", response_model=list[Stock])
    def watchlist():
        return [market.present_stock(s) for s in repo.list_watchlist()]

    @app.put("/watchlist/{ticker}")
    def add_watchlist(ticker: str):
        stock=require_stock(ticker)
        ticker=stock.ticker
        repo.add_watchlist(ticker)
        return {"ticker": ticker, "saved": True}

    @app.delete("/watchlist/{ticker}")
    def remove_watchlist(ticker: str):
        stock=require_stock(ticker)
        ticker=stock.ticker
        repo.remove_watchlist(ticker)
        return {"ticker": ticker, "saved": False}

    @app.get("/settings", response_model=AppSettings)
    def settings():
        return repo.get_settings()

    @app.patch("/settings", response_model=AppSettings)
    def save_settings(patch: SettingsPatch):
        try:
            return repo.update_settings(patch.model_dump(mode="json", exclude_unset=True))
        except ValidationError:
            raise HTTPException(422, "設定値が不正です。各期間の重みの合計を100にしてください。") from None

    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(ROOT / "frontend/index.html")

    @app.get("/manifest.webmanifest", include_in_schema=False)
    def manifest():
        return FileResponse(ROOT / "frontend/manifest.webmanifest", media_type="application/manifest+json")

    app.mount("/assets", StaticFiles(directory=ROOT / "frontend/assets"), name="assets")
    app.mount("/icons", StaticFiles(directory=ROOT / "frontend/icons"), name="icons")
    return app


app = create_app()
