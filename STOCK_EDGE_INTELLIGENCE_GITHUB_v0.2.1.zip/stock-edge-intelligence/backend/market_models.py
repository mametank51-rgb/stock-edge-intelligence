"""BLOCK 2 market-data contracts; no analytical scores or signals."""
from datetime import date, datetime
from typing import Literal

from pydantic import Field, model_validator

from .models import Candle, Stock, StrictModel


class Instrument(StrictModel):
    ticker: str
    company: str
    company_en: str = ""
    sector: str
    exchange: str = "TSE"
    market: str = "JP"
    currency: str = "JPY"
    provider_id: Literal["dummy", "jquants"]
    is_dummy: bool
    snapshot_date: date


class DailyPrice(Candle):
    adjusted_open: float = Field(gt=0)
    adjusted_high: float = Field(gt=0)
    adjusted_low: float = Field(gt=0)
    adjusted_close: float = Field(gt=0)
    adjusted_volume: float = Field(ge=0)
    adjustment_factor: float = Field(gt=0, default=1)

    @model_validator(mode="after")
    def adjusted_bounds(self):
        Candle(time=self.time, open=self.adjusted_open, high=self.adjusted_high,
               low=self.adjusted_low, close=self.adjusted_close, volume=self.adjusted_volume)
        return self

    def candle(self, basis: str) -> Candle:
        prefix = "adjusted_" if basis == "adjusted" else ""
        return Candle(time=self.time, **{k: getattr(self, prefix+k) for k in ("open", "high", "low", "close", "volume")})


class DisplayCandle(Candle):
    end_date: date | None = None
    observed_sessions: int = 1
    is_partial: bool = False


class PriceSeries(StrictModel):
    ticker: str
    interval: Literal["1d", "1wk"]
    basis: Literal["raw", "adjusted"]
    source: str
    provider_id: str
    is_dummy: bool
    updated_at: datetime
    data_as_of: date
    fetched_at: datetime | None
    last_attempt_at: datetime | None
    cache_status: Literal["seed", "fresh", "stale", "stale_error"]
    cache_age_seconds: float | None
    error_code: str | None = None
    error_message: str | None = None
    retry_after: int | None = None
    skipped_rows: int = 0
    warnings: list[str] = Field(default_factory=list)
    candles: list[DisplayCandle]
    stock: Stock
