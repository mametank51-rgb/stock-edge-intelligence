# STOCK EDGE INTELLIGENCE

**BLOCK 2 — GitHub公開準備版 / v0.2.1**

ソース公開とGitHub Pagesデモに対応しました。手順は **[GITHUB_PUBLISH.md](GITHUB_PUBLISH.md)** を参照してください。

| 使い方 | 実行場所・保存先 |
|---|---|
| GitHub Pagesデモ | 架空データで動作。設定・watchlistは閲覧者のブラウザ内 |
| Backend版 | FastAPI・SQLiteをPC/サーバーで起動。実データはBackend経由 |

GitHubリポジトリへのpush・Pagesへの実公開はまだ行っていません。
公開用ZIPにはDB、backup、実行ログ、秘密.envを含めず、初回起動でSQLiteを作成します。
GitHub Pagesは静的配信のため、Python Backendは別途必要です。Pages単独では架空デモとして操作できます。

BLOCK 1へ差分追加したWebアプリです。FastAPI・SQLite・既存5画面を維持し、
Provider、銘柄検索、日足/週足、価格調整切替、キャッシュ、取得情報、失敗時fallbackを追加しました。
**BLOCK 3以降の分析・予測は未実装です。**

初期設定のDummyProviderは固定架空データです。
J-Quants公式API用Adapterも実装していますが、APIキーがないため実接続は未検証です。
正常系・異常系はHTTP MockTransportで検証し、実データ取得成功と区別しています。

## 起動

必要環境：Python 3.11以降（検証3.12）、モダンブラウザ、初回依存導入用ネット接続。
通常起動にNode.jsやAPIキーは不要です。

Windows：ZIPをすべて展開し、Pythonを用意して`start.bat`をダブルクリック。
macOS/Linux：プロジェクト直下で`sh start.sh`を実行。
ブラウザで **http://127.0.0.1:8000** を開きます。終了はターミナルでCtrl+C。

手動起動：

```bash
python -m venv .venv
# Windows:
# .venv\Scripts\python -m pip install -r requirements.txt -c constraints.txt
# .venv\Scripts\python run.py
# macOS/Linux:
.venv/bin/python -m pip install -r requirements.txt -c constraints.txt
.venv/bin/python run.py
```

`python`がない場合は`python3`を使ってください。
`run.py`がBackendとFrontendを同一ポートで配信するので、Frontendのビルドは不要です。
HTMLをファイルとして直接開く方式ではありません。

## BLOCK 1からの引継ぎ

**先に[MIGRATION.md](MIGRATION.md)を読んでください。**
BLOCK 2を別フォルダへ展開し、旧アプリを停止して、使っていたDBを新フォルダへコピーします。
公開用ZIPにはDBがありません。既存の利用DBはGitへ追加せず、ローカル側で引き継いでください。
初回起動時にv1→v2へ自動移行し、移行前バックアップを作ります。
ウォッチリスト・テーマ・重み・旧価格履歴は保持します。

## 操作

| 画面 | 操作 |
|---|---|
| HOME | 銘柄一覧を更新→コード/社名/業種で検索→価格を取得して追加/詳細を開く |
| STOCK DETAIL | 日足/週足、調整済み/未調整、30本/60本/全期間、価格を更新 |
| RANKING | 保存済み銘柄の絞込・並替。Dummyは固定スコア、実データは未算出 |
| WATCHLIST | 登録・削除。提供元を切り替えても保存銘柄は残る |
| SETTINGS | Dummy/J-Quants、Backend URL、Dark/Light、Debugを保存 |

Market Today/Market ContextはDUMMY表示サンプルです。市場レジーム判定はありません。
実データの候補ランキング・テクニカル指標・Bull/Base/Bear生成は後続BLOCKです。

## J-Quantsの設定

1. 自分のAPIキーを取得します。
2. `.env.example`を`.env`へコピーし、Backend側だけに設定します。

```dotenv
JQUANTS_API_KEY=自分のAPIキー
JQUANTS_PLAN=free
```

3. Backendを再起動します。
4. 設定画面の提供元をJ-Quants V2にして保存します。
5. HOMEで銘柄一覧を更新し、検索して価格を取得します。

Freeは12週間遅延です。有料契約ならplanを`light / standard / premium`へ合わせてください。
APIキーをHTML/JavaScript・Backend URL欄に入力しないでください。
キー未設定でも画面は停止せず設定不足を表示し、実在銘柄に架空価格を付けません。
詳細・一次資料：[DATA_PROVIDERS.md](DATA_PROVIDERS.md)

## 価格・キャッシュ

- 価格基準日と取得成功日時を分けて表示します。
- 銘柄価格は未調整終値。騰落率は前観測日の調整済み終値比。1本だけなら「—」。
- チャートは調整済みが既定。未調整へ切替可能。
- 週足は観測日足を月曜始まりで集計。休場日・無約定日を補完しません。
- 進行週・境界週の未確定可能性を保持します。独立した取引所カレンダーは未実装です。
- キャッシュは既定24時間。期限超過時または「価格を更新」で再取得します。
- 失敗時は前回の価格と取得日時を保持し、警告を表示します。
- 実データは550暦日要求ウィンドウの完全取得結果で対象銘柄のキャッシュを置換し、調整基準の混在を防ぎます。
- 価格キャッシュは可変です。不変の予測履歴はBLOCK 13の対象です。

## 分離して開発する場合

```bash
# 仮想環境を有効化したプロジェクト直下：Backend
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
# 別ターミナル：Frontend
python -m http.server 5173 --directory frontend --bind 127.0.0.1
```

http://127.0.0.1:5173 を開き、Backend URLに `http://127.0.0.1:8000` を保存します。
CORS許可originは`.env`の`STOCK_EDGE_CORS_ORIGINS`で指定します。
同時起動の場合、Backend URLは空欄のまま使えます。APIドキュメントは `/docs`、起動/DB状態は `/health`。

## Android Chrome

Webアプリなので、PC/サーバーのBackendが必要です。APKではありません。
家庭内Wi-Fiでは`.env`の`STOCK_EDGE_HOST=0.0.0.0`で起動し、スマートフォンから
`http://PCのLAN内IP:8000`を開きます。Backend URLは空欄です。
スマートフォンのlocalhostはPCを指しません。必要ならPCのファイアウォールで家庭内からの8000番接続を許可してください。
1ユーザー・ローカル利用向けで、公開運用用の認証・ユーザー分離はありません。
390px幅で確認しましたが、Android実機は未検証です。

## Backend API

| Method | Path | 内容 |
|---|---|---|
| GET | /health | バージョン・DB・選択提供元・価格基準日 |
| GET | /stocks、/stocks/{ticker} | 選択提供元の保存済み一覧・銘柄詳細 |
| GET | /stocks/{ticker}/prices | interval=1d/1wk、basis=raw/adjusted、キャッシュ使用 |
| POST | /stocks/{ticker}/refresh | 明示更新。銘柄一覧にある未登録銘柄も取得・保存 |
| GET | /market/providers | 提供元と設定有無。キーは返さない |
| GET | /market/search | q、limitで保存済み銘柄一覧を検索 |
| POST | /market/catalog/refresh | 提供元から銘柄一覧を取得・保存 |
| GET | /ranking | Dummy固定値の並替。実データはスコアnull |
| GET / PUT / DELETE | /watchlist、/watchlist/{ticker} | 一覧・登録・削除 |
| GET / PATCH | /settings | 表示設定・提供元・将来用重み |

更新失敗でキャッシュがある場合は200と`cache_status=stale_error`を返します。
キャッシュもない場合は404/409/429/503等と`error_code`を返します。
FrontendはHTTP成功だけで更新完了とせず、error_codeも確認します。

## 構成・保存

Frontend → FastAPI → MarketDataService → Provider / Repository → SQLite。
外部認証通信はBackendだけです。通常利用に外部CDNは不要です。

- `backend/providers.py`：Provider Protocol、Dummy、J-Quants Adapter。
- `backend/market_data.py`：キャッシュ、fallback、週足。
- `backend/repository.py`：SQL・トランザクション・DB移行。
- `frontend/assets/app.js`：既存5画面と操作。
- `frontend/assets/market-view.js`：検索・取得情報・提供元設定の表示。
- `frontend/assets/chart.js`：自前SVGチャート。
- `database/stock_edge.db`：初回起動で作成する利用DB。Git・公開ZIPから除外。
- `database/migrations/`：差分移行SQL。
- `logs/app.log`：ローテーションログ。実行ログは配布ZIPに含めません。

SQLiteはstocks / price_history / watchlist / settings / instruments / price_adjustments / data_cacheの7テーブル。
Backend URLのみブラウザのlocalStorageに保存します。DBのバックアップはアプリを停止して行ってください。

## テスト

```bash
python -m pip install -r requirements-dev.txt -c constraints.txt
python -m pytest -q
# 以下だけNode.js 20以降が必要
npm run check
python scripts/build_pages.py
npm test
```

63件のPythonテスト、Pagesデモ等のNodeテスト9件（接続URL検証10項目を含む）、構文・ブラウザ確認を実施。
テスト用HTTPはMockTransport、テストDBは一時ディレクトリを使います。

## 成果物と次回

- CHANGELOG.md：BLOCK 2の追加内容と変更ファイル。
- FEATURES.md：実装済み/未実装。
- TEST_REPORT.md：検証範囲と限界。
- NEXT_BLOCK.md：BLOCK 3への引継ぎ。
- PROJECT_TREE.md：ファイル一覧。
- PACKAGE_CHECK.txt：展開後検証。SHA256SUMS.txt：ファイル整合性。

実キー接続・提供元実値照合・Windows/macOS/Android実機・PWAオフラインは未検証です。
Pagesデモは公開可能な状態まで準備しましたが、GitHub上のCI実行と公開URLは未確認です。
APK・EXE、Backend認証、分散レート制御、定期収集は含みません。
Pages公開は手動workflowです。一般公開するBackendの運用設計はSECURITY.mdを参照してください。
OSSライセンスは未選択です。権利者が決めてLICENSEを追加する手順をCONTRIBUTING.mdに記載しています。
BLOCK 3（Basic Technical Engine）へは次のユーザー指示を受けてから進みます。
