import {createDemo} from './demo-core.js';
let instance;
export async function demoRequest(path,options) {
  if(!instance) instance=(async()=>{
    const response=await fetch(new URL('./demo-data.json',import.meta.url),{cache:'no-store'});
    if(!response.ok) throw new Error('公開デモのデータを取得できません。Pagesのビルドを確認してください。');
    return createDemo(await response.json(),localStorage);
  })().catch(error=>{instance=null;throw error;});
  return (await instance)(path,options);
}
