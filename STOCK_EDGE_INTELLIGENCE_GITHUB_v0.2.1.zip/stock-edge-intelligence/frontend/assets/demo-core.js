// Browser-only fictional demo. It never calls a stock provider or claims a running backend.
const copy = value => JSON.parse(JSON.stringify(value));
const scoreKeys = ['technical','fundamental','intelligence','market'];
export const DEMO_KEY='stock-edge-pages-v1:'+new URL('../',import.meta.url).pathname;
const fail = (code,message) => {throw new Error(`DEMO ${code} · ${message}`);};

export function createDemo(data, storage, now=()=>new Date()) {
  if(data?.schema!=='stock-edge-pages-demo-v1') throw new Error('公開デモデータの形式が不正です。');
  const defaults=()=>({version:1,settings:copy(data.settings),watchlist:data.stocks.slice(0,3).map(s=>s.ticker),catalogFetched:null,pricesFetched:{}});
  function read() {
    let raw;
    try {raw=storage.getItem(DEMO_KEY);} catch {throw new Error('ブラウザ内デモの保存領域を利用できません。保存設定を確認してください。');}
    if(raw==null) return defaults();
    try {
      const value=JSON.parse(raw);
      if(value.version!==1||!Array.isArray(value.watchlist)||!value.settings||!value.pricesFetched||!['dark','light'].includes(value.settings.theme)) throw new Error();
      if(value.watchlist.some(t=>!data.stocks.some(s=>s.ticker===t))) throw new Error();
      return value;
    } catch {throw new Error('ブラウザ内デモの保存データを読み込めません。このサイトの保存データを確認してください。');}
  }
  function save(value) {
    try {storage.setItem(DEMO_KEY,JSON.stringify(value));} catch {throw new Error('ブラウザ内へ保存できませんでした。保存容量・設定を確認してください。');}
  }
  const provider={id:'dummy',name:'Browser Demo / 架空',configured:true,is_dummy:true,plan:null,delay_days:null,message:'GitHub Pages用の架空デモ。設定・ウォッチはこのブラウザだけに保存します。'};
  function stock(ticker) {const s=data.stocks.find(s=>s.ticker===ticker);if(!s) fail(404,'架空銘柄がありません。');return s;}
  function shown(s,state) {return {...copy(s),fetched_at:state.pricesFetched[s.ticker]||null};}
  const utcDay = d=>new Date(d+'T00:00:00Z');
  const dayText = d=>d.toISOString().slice(0,10);
  function weekly(rows) {
    const groups=new Map();
    for(const row of rows) {
      const monday=utcDay(row.time);monday.setUTCDate(monday.getUTCDate()-(monday.getUTCDay()+6)%7);
      const key=dayText(monday);if(!groups.has(key)) groups.set(key,[]);groups.get(key).push(row);
    }
    const today=dayText(new Date(now().getTime()+9*3600*1000));
    const current=utcDay(today);current.setUTCDate(current.getUTCDate()-(current.getUTCDay()+6)%7);
    return [...groups].map(([monday,items],index)=>{
      const friday=utcDay(monday);friday.setUTCDate(friday.getUTCDate()+4);
      return {time:monday,end_date:items.at(-1).time,open:items[0].open,high:Math.max(...items.map(r=>r.high)),
        low:Math.min(...items.map(r=>r.low)),close:items.at(-1).close,volume:items.reduce((a,b)=>a+b.volume,0),
        observed_sessions:items.length,is_partial:monday>=dayText(current)||(index===0&&items[0].time>monday)||(index===groups.size-1&&items.at(-1).time<dayText(friday))};
    });
  }
  function series(ticker,state,url) {
    const item=shown(stock(ticker),state), interval=url.searchParams.get('interval')||'1d',basis=url.searchParams.get('basis')||'adjusted';
    if(!['1d','1wk'].includes(interval)||!['raw','adjusted'].includes(basis)) fail(422,'足種または価格調整が不正です。');
    const fetched=state.pricesFetched[ticker]||null;
    return {ticker,interval,basis,source:item.source,provider_id:'dummy',is_dummy:true,updated_at:item.updated_at,data_as_of:item.data_as_of,
      fetched_at:fetched,last_attempt_at:fetched,cache_status:fetched?'fresh':'seed',cache_age_seconds:fetched?Math.max(0,(now()-new Date(fetched))/1000):null,
      error_code:null,error_message:null,retry_after:null,skipped_rows:0,
      warnings:['GitHub Pages上の架空デモです。Backend・実株価APIには接続していません。', '更新は固定サンプルの再表示で、株価の取得ではありません。'],
      candles:interval==='1wk'?weekly(data.history[ticker]):copy(data.history[ticker]).map(r=>({...r,end_date:null,observed_sessions:1,is_partial:false})),stock:item};
  }
  return async (path,options={})=>{
    const url=new URL(path,'https://demo.invalid'), route=url.pathname,method=options.method||'GET',state=read();
    if(method==='GET'&&route==='/health') return {status:'ok',version:'0.2.1',block:2,mode:'dummy',runtime:'browser-demo',source:'BLOCK1_SYNTHETIC',data_as_of:data.stocks[0].data_as_of,database:{status:'browser-local',schema_version:2,stock_count:data.stocks.length}};
    if(method==='GET'&&route==='/market/providers') return {selected:'dummy',providers:[provider],cache_ttl_seconds:86400,history_window_calendar_days:550};
    if(method==='GET'&&route==='/settings') return copy(state.settings);
    if(method==='PATCH'&&route==='/settings') {
      let patch;try{patch=JSON.parse(options.body);}catch{fail(422,'設定JSONが不正です。');}
      if(!patch||Array.isArray(patch)||typeof patch!=='object'||Object.keys(patch).some(k=>!['theme','market','debug_mode','market_data_provider','weights'].includes(k))) fail(422,'設定項目が不正です。');
      if(Object.values(patch).some(v=>v===null)) fail(422,'設定にnullは指定できません。');
      if('market_data_provider'in patch&&patch.market_data_provider!=='dummy') fail(422,'実データには別途HTTPS Backend URLを設定してください。');
      if(('theme'in patch&&!['dark','light'].includes(patch.theme))||('market'in patch&&patch.market!=='JP')||('debug_mode'in patch&&typeof patch.debug_mode!=='boolean')) fail(422,'設定値が不正です。');
      if('weights'in patch&&(!patch.weights||typeof patch.weights!=='object'||Array.isArray(patch.weights))) fail(422,'重みの形式が不正です。');
      if(patch.weights&&Object.keys(patch.weights).sort().join(',')!=='20,5,60') fail(422,'重みの期間が不正です。');
      if(patch.weights) for(const h of ['5','20','60']) {
        const w=patch.weights[h];if(!w||scoreKeys.some(k=>!Number.isFinite(w[k])||w[k]<0||w[k]>100)||Math.abs(scoreKeys.reduce((s,k)=>s+w[k],0)-100)>.001) fail(422,'重みは各期間100にしてください。');
      }
      state.settings={...state.settings,...patch};save(state);return copy(state.settings);
    }
    if(method==='GET'&&route==='/stocks') return data.stocks.map(s=>shown(s,state));
    if(method==='GET'&&route==='/ranking') return data.stocks.map(s=>shown(s,state)).sort((a,b)=>b.scores.edge-a.scores.edge);
    if(method==='GET'&&route==='/watchlist') return state.watchlist.map(t=>shown(stock(t),state));
    const watch=route.match(/^\/watchlist\/([^/]+)$/);
    if(watch&&['PUT','DELETE'].includes(method)) {
      const ticker=decodeURIComponent(watch[1]);stock(ticker);
      state.watchlist=method==='PUT'?[...new Set([...state.watchlist,ticker])]:state.watchlist.filter(t=>t!==ticker);
      save(state);return {ticker,saved:method==='PUT'};
    }
    if((method==='GET'&&route==='/market/search')||(method==='POST'&&route==='/market/catalog/refresh')) {
      if(method==='POST') {state.catalogFetched=now().toISOString();save(state);}
      const q=(url.searchParams.get('q')||'').normalize('NFKC').toLowerCase(),limit=Number(url.searchParams.get('limit')||30);
      if(q.length>120||!Number.isInteger(limit)||limit<1||limit>100) fail(422,'検索条件が不正です。');
      const items=data.stocks.filter(s=>`${s.ticker} ${s.company} ${s.sector}`.toLowerCase().includes(q));
      return {provider_id:'dummy',total_catalog:data.stocks.length,total_matches:items.length,
        items:items.slice(0,limit).map(s=>({ticker:s.ticker,company:s.company,company_en:'',sector:s.sector,exchange:s.exchange,market:'JP',currency:'JPY',provider_id:'dummy',is_dummy:true,snapshot_date:s.data_as_of,imported:true})),
        fetched_at:state.catalogFetched,data_as_of:data.stocks[0].data_as_of,cache_status:state.catalogFetched?'fresh':'seed',error_code:null,error_message:null,provider};
    }
    const prices=route.match(/^\/stocks\/([^/]+)\/(prices|refresh)$/);
    if(prices&&((method==='GET'&&prices[2]==='prices')||(method==='POST'&&prices[2]==='refresh'))) {
      const ticker=decodeURIComponent(prices[1]);stock(ticker);
      if(method==='POST') {state.pricesFetched[ticker]=now().toISOString();save(state);}
      return series(ticker,state,url);
    }
    const detail=route.match(/^\/stocks\/([^/]+)$/);
    if(detail&&method==='GET') return shown(stock(decodeURIComponent(detail[1])),state);
    fail(404,'このデモでは利用できない操作です。');
  };
}
