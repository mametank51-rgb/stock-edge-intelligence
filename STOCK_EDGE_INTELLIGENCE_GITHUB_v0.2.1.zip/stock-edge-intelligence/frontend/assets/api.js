const basePath=new URL('../',import.meta.url).pathname;
const STORAGE_KEY = 'stock-edge-backend-v1'+(basePath==='/'?'':':'+basePath);
let deployment;
async function isPagesDemo() {
  if(!deployment) deployment=fetch(new URL('./deployment.json',import.meta.url),{cache:'no-store'})
    .then(async response=>{
      if(response.status===404) return false;
      if(!response.ok) throw new Error('公開モードの設定を取得できません。');
      const value=await response.json();
      if(!['backend','pages-demo'].includes(value.mode)) throw new Error('公開モードの設定が不正です。');
      return value.mode==='pages-demo';
    }).catch(error=>{deployment=null;throw error;});
  return deployment;
}

export function readBackend() {
  try { return localStorage.getItem(STORAGE_KEY) || ''; } catch { return ''; }
}

export function normalizeBackend(input) {
  if (!input.trim()) return '';
  const url = new URL(input.trim());
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash || url.pathname !== '/') {
    throw new Error('Backend URLには http(s)://ホスト:ポート のみ指定してください。');
  }
  if (location.protocol === 'https:' && url.protocol === 'http:') {
    throw new Error('HTTPSの画面からHTTPのBackendへ接続できません。HTTPSのURLを指定してください。');
  }
  return url.origin;
}

export function saveBackend(url) {
  try {
    if (url) localStorage.setItem(STORAGE_KEY, url);
    else localStorage.removeItem(STORAGE_KEY);
  } catch { throw new Error('ブラウザが接続先の保存を拒否しました。保存設定を確認してください。'); }
}

export async function request(path, options = {}, backend = readBackend()) {
  if(!backend && await isPagesDemo()) {
    const {demoRequest}=await import('./demo-api.js');
    return demoRequest(path,options);
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(`${backend}${path}`, {
      ...options, signal: controller.signal,
      credentials: 'omit', cache: 'no-store',
      headers: { ...(options.body ? {'Content-Type': 'application/json'} : {}), ...options.headers },
    });
    const body = await response.json().catch(() => null);
    if (!response.ok) {
      const detail = typeof body?.detail === 'string' ? body.detail : '入力値またはサーバーの状態を確認してください。';
      throw new Error(`HTTP ${response.status} · ${detail}`);
    }
    if (!body) throw new Error('BackendからJSONを取得できませんでした。接続先を確認してください。');
    return body;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('接続がタイムアウトしました。Backendの起動を確認してください。');
    if (error instanceof TypeError) throw new Error('Backendに接続できません。起動状態・URL・CORS設定を確認してください。');
    throw error;
  } finally { clearTimeout(timer); }
}

export async function loadFoundation(backend = readBackend()) {
  const [health, stocks, ranking, watchlist, settings, providers] = await Promise.all([
    request('/health', {}, backend), request('/stocks', {}, backend), request('/ranking', {}, backend),
    request('/watchlist', {}, backend), request('/settings', {}, backend),
    request('/market/providers', {}, backend),
  ]);
  if (health.block !== 2 || !['dummy','jquants'].includes(health.mode) || !Array.isArray(stocks) || !Array.isArray(ranking) || !Array.isArray(watchlist) || !settings.theme || !Array.isArray(providers.providers)) {
    throw new Error('接続先がBLOCK 2 Backendの形式と一致しません。');
  }
  return {health, stocks, ranking, watchlist, settings, providers};
}
