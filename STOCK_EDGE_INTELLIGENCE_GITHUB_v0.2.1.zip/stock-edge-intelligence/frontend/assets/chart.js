// Dependency-free SVG chart, deliberately limited to OHLCV display in BLOCK 1.
// No technical indicator, pattern recognition, or target-price calculation.
const ns = 'http://www.w3.org/2000/svg';
function el(name, attrs = {}, text = '') {
  const node = document.createElementNS(ns, name);
  for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, value);
  if (text) node.textContent = text;
  return node;
}
const fmt = value => new Intl.NumberFormat('ja-JP', {maximumFractionDigits: 2}).format(value);

export function drawCandles(container, all, count = 60, meta = {}) {
  const data = all.slice(-count);
  container.replaceChildren();
  if (!data.length) { container.textContent = 'ローソク足データがありません。'; return; }
  const width = Math.max(container.clientWidth, 280);
  const height = 360, right = 66, left = 10, top = 28, bottom = 35;
  const plotW = width - right - left, plotH = 226;
  const min = Math.min(...data.map(d => d.low)), max = Math.max(...data.map(d => d.high));
  const pad = Math.max((max - min) * .12, max * .005);
  const lo = min - pad, hi = max + pad;
  const y = price => top + (hi - price) / (hi - lo) * plotH;
  const step = plotW / data.length, bodyW = Math.max(1, step * .59);
  const svg = el('svg', {viewBox: `0 0 ${width} ${height}`, role: 'img', 'aria-label': `${meta.is_dummy===false?'実データ':'架空'}のOHLCVローソク足チャート ${data.length}本。終値${fmt(data.at(-1).close)}円`});
  const description = el('desc', {}, `${meta.is_dummy===false?'提供元 '+meta.source+' の日次データです。':'合成データです。'}緑は陽線、赤は陰線。下段は出来高。`);
  svg.append(description);
  for (let i = 0; i <= 4; i++) {
    const py = top + i * plotH / 4;
    svg.append(el('line', {x1:left, x2:width-right, y1:py, y2:py, class:'chart-grid'}));
    svg.append(el('text', {x:width-right+10, y:py+4, class:'chart-label'}, fmt(hi-(hi-lo)*i/4)));
  }
  const maxVolume = Math.max(1, ...data.map(d => d.volume));
  data.forEach((d, i) => {
    const x = left + step * (i + .5), color = d.close >= d.open ? 'var(--up)' : 'var(--down)';
    svg.append(el('line', {x1:x, x2:x, y1:y(d.high), y2:y(d.low), stroke:color, 'stroke-width':1}));
    svg.append(el('rect', {x:x-bodyW/2, y:Math.min(y(d.open),y(d.close)), width:bodyW,
      height:Math.max(1,Math.abs(y(d.open)-y(d.close))), fill:color, rx:.6}));
    const volumeH = d.volume / maxVolume * 40;
    svg.append(el('rect', {x:x-bodyW/2, y:height-bottom-volumeH, width:bodyW, height:volumeH, fill:color, opacity:.23}));
  });
  [0, Math.floor(data.length/3), Math.floor(data.length*2/3), data.length-1].forEach(i => {
    svg.append(el('text', {x:left+step*(i+.5), y:height-10, class:'chart-label', 'text-anchor':'middle'}, data[i].time.slice(5).replace('-', '/')));
  });
  const last = data.at(-1), lastY = y(last.close);
  svg.append(el('line', {x1:left, x2:width-right, y1:lastY, y2:lastY, stroke:'var(--accent)', 'stroke-dasharray':'4 5', opacity:.5}));
  svg.append(el('rect', {x:width-right, y:lastY-10, width:right, height:20, rx:3, fill:'var(--accent)'}));
  svg.append(el('text', {x:width-right+right/2, y:lastY+4, fill:'var(--accent-text)', 'text-anchor':'middle', 'font-size':10}, fmt(last.close)));
  const cross = el('line', {y1:top, y2:height-bottom, class:'crosshair', visibility:'hidden'});
  svg.append(cross);
  const tooltip = document.createElement('div'); tooltip.className = 'chart-tooltip';
  tooltip.textContent = `日付に触れると OHLC・出来高を表示 · ${data.length}本${meta.interval==='1wk'?' / 週足':''}`;
  function select(index) {
    const d = data[index], x = left + step * (index + .5);
    cross.setAttribute('x1', x); cross.setAttribute('x2', x); cross.setAttribute('visibility', 'visible');
    tooltip.textContent = `${d.time}${d.end_date?'〜'+d.end_date:''}${d.is_partial?' (未確定の可能性)':''}  始 ${fmt(d.open)}  高 ${fmt(d.high)}  安 ${fmt(d.low)}  終 ${fmt(d.close)}  出来高 ${fmt(d.volume)}`;
  }
  let selected = data.length - 1;
  svg.setAttribute('tabindex', '0');
  svg.setAttribute('aria-description', '左右キーで日付を選択できます。');
  svg.addEventListener('pointermove', event => {
    const rect = svg.getBoundingClientRect();
    selected = Math.max(0, Math.min(data.length-1, Math.floor(((event.clientX-rect.left)*width/rect.width-left)/step)));
    select(selected);
  });
  svg.addEventListener('keydown', event => {
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      event.preventDefault();
      selected = Math.max(0, Math.min(data.length-1, selected+(event.key==='ArrowLeft'?-1:1)));
      select(selected);
    }
  });
  container.append(tooltip, svg);
}

export function sparkline(seed, positive = true) {
  const points = Array.from({length:25}, (_,i) => `${i*3.5},${22-Math.sin(i*.55+seed)*6-i*.43+(seed%3)*2}`).join(' ');
  return `<svg class="sparkline" viewBox="0 0 88 32" aria-hidden="true"><polyline points="${points}" fill="none" stroke="${positive?'var(--up)':'var(--down)'}" stroke-width="1.5"/></svg>`;
}
