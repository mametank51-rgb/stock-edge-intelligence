import {loadFoundation, normalizeBackend, readBackend, request, saveBackend} from './api.js';
import {drawCandles} from './chart.js';
import {marketPanel, providerSettings, searchResults, seriesStatus, sourceLabel} from './market-view.js';

const icons = {
  edge:'<path d="m4 17 6-7 4 3 6-9M15 4h5v5"/>',
  home:'<rect x="3" y="3" width="7" height="7" rx="1.3"/><rect x="14" y="3" width="7" height="7" rx="1.3"/><rect x="3" y="14" width="7" height="7" rx="1.3"/><rect x="14" y="14" width="7" height="7" rx="1.3"/>',
  rank:'<path d="M5 20V12M12 20V4M19 20V8"/>',
  chart:'<path d="M3 3v18h18M7 14l4-5 4 3 5-7"/>',
  star:'<path d="m12 3 2.8 5.6 6.2.9-4.5 4.4 1.1 6.1-5.6-2.9-5.6 2.9 1.1-6.1L3 9.5l6.2-.9Z"/>',
  settings:'<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="3"/><circle cx="15" cy="17" r="3"/>',
  refresh:'<path d="M20 8a8 8 0 1 0 0 8M20 3v5h-5"/>',
  search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
  arrow:'<path d="M4 12h16m-6-6 6 6-6 6"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
};
const icon = key => `<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[key]||icons.info}</svg>`;
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = value => new Intl.NumberFormat('ja-JP', {maximumFractionDigits:2}).format(value);
const change = value => value==null?'<span class="change">—</span>':`<span class="change ${value>=0?'up':'down'}">${value>=0?'+':''}${Number(value).toFixed(2)}%</span>`;
const price = stock => `${stock.currency==='JPY'?'¥':''}${money(stock.price)}`;
const asOf = value => value?new Intl.DateTimeFormat('ja-JP', {year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',timeZone:'Asia/Tokyo'}).format(new Date(value)):'未取得';
const scoreNames = {technical:'Technical',fundamental:'Fundamental',intelligence:'Intelligence',market:'Market',edge:'Edge',opportunity:'Opportunity',risk:'Risk',conviction:'Conviction',signal_diversity:'Signal diversity',conflict:'Conflict'};
const state = {data:null, error:'', loading:true, route:'home', ticker:'DMY001', detail:null, candles:[], range:60, query:'', sort:'edge', busy:new Set(),interval:'1d',basis:'adjusted',history:null,marketSearch:null,marketQuery:'',searchBusy:false,searchError:''};
let chartObserver, renderEpoch = 0, toastTimer;
const app = document.querySelector('#app');
const navItems = [ ['home','home','ホーム'], ['ranking','rank','ランキング'], ['stock','chart','銘柄詳細'], ['watchlist','star','ウォッチリスト'], ['settings','settings','設定'] ];

function toast(message, error=false) {
  const node = document.querySelector('#toast');
  node.textContent = message; node.className = `visible${error?' error':''}`;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => node.className='', 4500);
}

function parseRoute() {
  const parts = location.hash.replace(/^#\/?/, '').split('/');
  state.route = parts[0] || 'home';
  if (!navItems.some(([key])=>key===state.route)) state.route='not-found';
  if (state.route==='stock' && parts[1]) {
    try { state.ticker=decodeURIComponent(parts[1]); } catch { state.ticker='INVALID'; }
  }
}

function localDemo() {return state.data?.health.runtime==='browser-demo';}
function storageLabel() {return localDemo()?'このブラウザ内':'SQLite';}
function demoBanner(stock=null) {
  const dummy=stock?stock.is_dummy:state.data?.settings.market_data_provider!=='jquants';
  return `<div class="demo-banner">${icon('info')}<span><strong>${localDemo()?'GITHUB PAGES DEMO':dummy?'DEMO DATA':'MARKET DATA'}</strong> · ${dummy?'架空の銘柄・株価・固定スコアです。':'実データのスコアは未算出です。日次データの基準日を確認してください。'} BLOCK 2では分析を行いません。</span><span class="banner-tail">MARKET DATA / 02</span></div>`;
}

function shell(body) {
  const data=state.data, watchCount=data?.watchlist.length ?? 0;
  return `<div class="shell"><aside class="sidebar" aria-label="メインナビゲーション">
    <a class="brand" href="#/home"><span class="brand-mark">${icon('edge')}</span><span class="brand-name">STOCK EDGE<span class="brand-sub">INTELLIGENCE</span></span></a>
    <div class="nav-label">WORKSPACE</div>
    <nav class="nav">${navItems.map(([key,ico,label])=>`<a href="#/${key}${key==='stock'?'/'+encodeURIComponent(state.ticker):''}" class="${state.route===key?'active':''}" ${state.route===key?'aria-current="page"':''}>${icon(ico)}<span>${label}</span>${key==='watchlist'?`<span class="nav-count">${String(watchCount).padStart(2,'0')}</span>`:''}</a>`).join('')}</nav>
    <div class="side-divider"></div><div class="nav-label">ANALYSIS ENGINES</div>
    <div class="engine-list">${['Technical','Fundamental','Intelligence','Market Regime'].map(name=>`<div class="engine-row"><span>${name}</span><small>PLANNED</small></div>`).join('')}</div>
    <div class="foundation"><span class="eyebrow">DEVELOPMENT</span><strong>安定した土台から、一歩ずつ。</strong><span>BLOCK 2 · Market Data Engine</span><div class="progress"><span></span></div><div class="foundation-foot"><span>2 / 16 blocks</span><span>v0.2.1</span></div></div>
    </aside><div class="workspace"><header class="topbar"><div class="breadcrumb">Workspace <span>/</span><strong>${esc(navItems.find(([key])=>key===state.route)?.[2]||'ページ')}</strong></div>
    <a class="mobile-title" href="#/home"><span class="brand-mark">${icon('edge')}</span>STOCK EDGE</a>
    <div class="top-actions"><span class="connection"><i class="status-dot ${!data||state.error?'offline':''}"></i>${data&&!state.error?(localDemo()?'LOCAL DEMO':'API CONNECTED'):'API '+(state.loading?'CONNECTING':'OFFLINE')}</span><span class="pill demo">${data?.settings.market_data_provider==='jquants'?'J-QUANTS':'DEMO MODE'}</span><span class="avatar">SE</span></div></header>
    <main id="main" tabindex="-1">${body}<footer class="page-footer"><span>STOCK EDGE INTELLIGENCE <span aria-hidden="true">/</span> BLOCK 2</span><span>分析支援プラットフォーム · Market Data Engine</span></footer></main></div></div>`;
}

function heading(kicker,title,description,actions='') {
  return `<div class="page-head"><div><div class="eyebrow">${kicker}</div><h1>${title}</h1><p>${description}</p></div><div class="head-actions">${actions}</div></div>`;
}
function refreshButton() {return `<button class="btn" data-action="refresh">${icon('refresh')}<span>再読込</span></button>`;}
function watchButton(stock, small=false) {
  const saved = state.data.watchlist.some(s=>s.ticker===stock.ticker);
  return `<button class="${small?'star-btn':'btn'} ${saved?'saved':''}" data-watch="${esc(stock.ticker)}" aria-label="${esc(stock.company)}を${saved?'ウォッチリストから削除':'ウォッチリストへ追加'}" aria-pressed="${saved}" ${state.busy.has(stock.ticker)?'disabled':''}>${icon(saved?'check':'star')}${small?'':saved?'登録済み':'ウォッチに追加'}</button>`;
}

function candidate(stock,index) {
  return `<a href="#/stock/${esc(stock.ticker)}" class="candidate ${index===0?'first':''}"><div class="candidate-top"><span class="rank-num">0${index+1}</span><span class="sector-chip">${esc(stock.sector)}</span></div><div class="ticker">${esc(stock.ticker)} · ${sourceLabel(stock)}</div><div class="company">${esc(stock.company)}</div><div class="candidate-price">${price(stock)}${change(stock.change_pct)}</div><div class="edge-row"><div><div class="edge-label">${stock.is_dummy?'DUMMY EDGE':'未算出 EDGE'}</div><div class="edge-number">${stock.scores.edge??'—'}<small> / 100</small></div></div><div class="risk-block"><div class="risk-label">RISK</div><div class="risk-value">${stock.scores.risk??'—'} <span class="not-ready">/ 100</span></div></div></div><div class="score-track"><span style="width:${stock.scores.edge??0}%"></span></div></a>`;
}

function chartPanel(stock, detail=false) {
  return `<section class="panel"><div class="panel-header"><div><div class="chart-title"><i class="status-dot"></i>${esc(stock.company)} <span class="ticker">${esc(stock.ticker)}</span></div><div class="chart-header-quote">${price(stock)}${change(stock.change_pct)}</div></div><div class="segmented" aria-label="チャート表示本数">${[30,60,0].map(n=>`<button data-range="${n}" class="${state.range===n?'active':''}" aria-pressed="${state.range===n}">${n===0?'全期間':n+'本'}</button>`).join('')}</div></div>
    <div class="chart-controls"><div class="segmented" aria-label="足種">${[['1d','日足'],['1wk','週足']].map(([v,label])=>`<button data-interval="${v}" class="${state.interval===v?'active':''}" aria-pressed="${state.interval===v}">${label}</button>`).join('')}</div><label>価格 <select id="price-basis" aria-label="価格調整"><option value="adjusted" ${state.basis==='adjusted'?'selected':''}>調整済み</option><option value="raw" ${state.basis==='raw'?'selected':''}>未調整</option></select></label><button class="btn small" data-chart-refresh="${esc(stock.ticker)}">価格を更新</button></div>
    <div class="chart-container" id="candlestick-chart"><div class="loading">チャートを読み込み中…</div></div><div class="chart-footer"><div class="legend"><span>陽線</span><span>陰線</span></div><span>${state.interval==='1wk'?'週足（月曜始まり）':'日足'} / ${stock.is_dummy?'合成データ':'J-Quants'}${detail?' · 分析は未実装':''}</span></div>${seriesStatus(state.history)}</section>`;
}

function watchMini() {
  const items = state.data.watchlist;
  return `<section class="panel"><div class="panel-header"><h2>ウォッチリスト <span class="ticker">${items.length}</span></h2><a class="text-link" href="#/watchlist">すべて →</a></div><div class="panel-body">${items.length?items.slice(0,4).map(s=>`<a class="watch-item" href="#/stock/${esc(s.ticker)}"><span class="initial">${esc(s.company[0])}</span><div class="watch-name"><div class="company">${esc(s.company.replace('（架空）',''))}</div><div class="ticker">${esc(s.ticker)} · ${sourceLabel(s)}</div></div><div class="watch-quote">${price(s)}${change(s.change_pct)}</div></a>`).join(''):'<p class="not-ready">登録銘柄はありません。<a href="#/ranking" class="text-link">銘柄一覧へ →</a></p>'}</div></section>`;
}

function home() {
  const data = state.data;
  const demo=data.settings.market_data_provider==='dummy';
  const first=data.ranking[0];
  return heading('YOUR MARKET WORKSPACE','市場を、多角的に。','異なる視点をつなぎ、根拠から次の一手を考える。',refreshButton())+demoBanner()+
    `<section class="market-strip" aria-label="市場・データサマリー">
      <div class="market-tile"><div class="market-top">MARKET TODAY <span class="tag">DUMMY</span></div><div class="market-value">Neutral <small>→</small></div><div class="market-meta">日本市場 / 状態表示サンプル</div></div>
      <div class="market-tile"><div class="market-top">${demo?'SAMPLE UNIVERSE':'SAVED UNIVERSE'}</div><div class="market-value">${String(data.stocks.length).padStart(2,'0')} <small>銘柄</small></div><div class="market-meta">${demo?'架空データ':'取得済み実データ'}</div></div>
      <div class="market-tile"><div class="market-top">WATCHING</div><div class="market-value">${String(data.watchlist.length).padStart(2,'0')} <small>銘柄</small></div><div class="market-meta">${storageLabel()}に保存済み</div></div>
      <div class="market-tile"><div class="market-top">DATA AS OF · JST</div><div class="market-value market-date">${esc(data.health.data_as_of||'未取得')}</div><div class="market-meta">${demo?'合成データの基準日':'保存済み日足の最大基準日'}</div></div>
    </section>${marketPanel(state)}<div class="content-grid"><div>
      <div class="section-top"><div class="section-title">${demo?'Top candidates':'Saved stocks'} <span class="mini-label">${demo?'DUMMY RANKING':'NOT ANALYZED'}</span></div><a class="text-link" href="#/ranking">すべての銘柄 →</a></div>
      <div class="candidate-cards">${data.ranking.slice(0,3).map(candidate).join('')}</div>
      ${first?chartPanel(first):'<div class="panel empty">まだ取得済み銘柄がありません。上の銘柄検索から価格を取得してください。</div>'}
      <section class="panel recent-panel"><div class="panel-header"><h2>Recent analysis</h2><span class="tag">UI SAMPLE</span></div><div class="timeline">
        <div class="timeline-item"><small>FOUNDATION / 01</small><p>${demo?'架空OHLCVを表示':'市場データ取得の基盤'}</p><span>数値からローソク足を描画</span></div>
        <div class="timeline-item"><small>ANALYSIS / PENDING</small><p>解析履歴はまだありません</p><span>分析エンジンは後続BLOCK</span></div>
        <div class="timeline-item"><small>TRACKING / PENDING</small><p>予測の保存はBLOCK 13</p><span>${demo?'現在のスコアは固定サンプル':'現在のスコアは未算出'}</span></div>
      </div></section>
    </div><aside class="right-column">
      <section class="panel"><div class="panel-header"><h2>Market context</h2><span class="tag">DUMMY</span></div><div class="panel-body"><div class="regime-ring" aria-hidden="true"></div><div class="regime-label">中立 / Neutral</div><div class="regime-copy">市場判定の表示サンプル</div><div class="facts"><div class="fact"><span>対象市場</span><strong>日本株 · JP</strong></div><div class="fact"><span>選択中の提供元</span><strong>${demo?'DummyProvider':'J-Quants V2'}</strong></div><div class="fact"><span>Market Regime Engine</span><strong>BLOCK 10</strong></div></div></div></section>
      ${watchMini()}
      <section class="panel roadmap-panel"><div class="panel-header"><h2>Build in blocks</h2><span class="ticker">02 / 16</span></div><div class="panel-body"><div class="roadmap-row"><span class="roadmap-step">01</span><div><strong>App Foundation</strong><span class="ready-tag">COMPLETE</span><p>UI・API・DB・保存の土台</p></div></div><div class="roadmap-row"><span class="roadmap-step">02</span><div><strong>Market Data Engine</strong><span class="ready-tag">CURRENT</span><p>実装済み：取得・保存・キャッシュ</p></div></div></div></section>
    </aside></div>`;
}

function tableStocks(stocks, isWatch=false) {
  if (!stocks.length) return `<div class="empty"><h2>${isWatch?'ウォッチリストは空です':'該当する保存済み銘柄がありません'}</h2><p>${isWatch?'ランキングの星ボタンで銘柄を登録できます。':'銘柄名・コード・業種で絞り込んでください。'}</p>${isWatch?'<a class="btn primary" href="#/ranking">銘柄一覧を見る</a>':''}</div>`;
  return `<div class="table-scroll"><table class="stock-table"><thead><tr><th>表示順</th><th>銘柄 / TICKER</th><th>価格 / 前日比</th><th>Technical</th><th>Fundamental</th><th>Intelligence</th><th>Market</th><th>Edge ${state.sort==='edge'?'↓':''}</th><th>Risk ${state.sort==='risk'?'↑':''}</th><th>登録</th></tr></thead><tbody>${stocks.map((s,i)=>`<tr><td class="ticker">${String(i+1).padStart(2,'0')}</td><td><a href="#/stock/${esc(s.ticker)}"><div class="company">${esc(s.company)}</div><div class="ticker">${esc(s.ticker)} · ${sourceLabel(s)} · ${esc(s.sector)}</div></a></td><td>${price(s)}<br>${change(s.change_pct)}</td>${['technical','fundamental','intelligence','market','edge','risk'].map(k=>`<td class="${k==='edge'?'edge-cell':'score-cell'}">${s.scores[k]??'—'}</td>`).join('')}<td>${watchButton(s,true)}</td></tr>`).join('')}</tbody></table></div>`;
}

function filterStocks(items) {
  const query = state.query.trim().toLowerCase();
  return items.filter(s=>`${s.ticker} ${s.company} ${s.sector}`.toLowerCase().includes(query))
    .sort((a,b)=>state.sort==='ticker'?a.ticker.localeCompare(b.ticker):state.sort==='risk'?(a.scores.risk??101)-(b.scores.risk??101):(b.scores.edge??-1)-(a.scores.edge??-1));
}

function ranking(isWatch=false) {
  const stocks = isWatch?state.data.watchlist:state.data.ranking;
  return heading(isWatch?'YOUR OBSERVATION LIST':'SAMPLE UNIVERSE',isWatch?'ウォッチリスト':'候補ランキング',isWatch?'気になる銘柄を保存して、変化を追う。':'分析ランキングは未実装。架空銘柄の固定スコアと、実データの未算出を区別します。',refreshButton())+demoBanner()+
    `<div class="table-tools"><div class="input-wrap">${icon('search')}<input id="stock-filter" type="search" aria-label="銘柄を絞り込み" placeholder="銘柄名・コード・業種で絞り込み" value="${esc(state.query)}"></div><label><span class="eyebrow">SORT </span><select id="stock-sort" aria-label="表示順"><option value="edge" ${state.sort==='edge'?'selected':''}>Dummy Edge 高い順</option><option value="risk" ${state.sort==='risk'?'selected':''}>Dummy Risk 低い順</option><option value="ticker" ${state.sort==='ticker'?'selected':''}>コード順</option></select></label></div>
    <section class="panel"><div class="panel-header"><h2>${isWatch?'Saved stocks':'All candidates'} <span class="ticker" id="result-count">${filterStocks(stocks).length} / ${stocks.length}</span></h2><span class="tag">DEMO = DUMMY / REAL = 未算出</span></div><div id="stock-results">${tableStocks(filterStocks(stocks),isWatch)}</div></section>
    <p class="table-scroll-hint">表を横にスワイプすると、スコア・登録ボタンが表示されます。</p><p class="setting-note">Technical Breakout・Fundamental Improvement・Intelligence Consensus等の分析別ランキングは、後続BLOCKで実装します。</p>`;
}

function scores(stock, keys) {
  return `<div class="score-grid">${keys.map(k=>`<div class="score-card"><label>${scoreNames[k]} <span class="tag">${stock.is_dummy?'DUMMY':'未算出'}</span></label><strong class="${k==='edge'?'up':''}">${stock.scores[k]??'—'} <small>/ 100</small></strong><div class="score-track"><span style="width:${stock.scores[k]??0}%;opacity:${k==='risk'||k==='conflict'?'.4':'.8'}"></span></div></div>`).join('')}</div>`;
}

function detail(stock) {
  return `<div class="page-head"><div class="stock-head"><div class="stock-symbol">${esc(stock.company[0])}</div><div><div class="eyebrow">${esc(stock.ticker)} · ${esc(stock.exchange)} · ${esc(stock.sector)}</div><h1>${esc(stock.company)}</h1><div class="stock-price-large">${price(stock)}${change(stock.change_pct)}</div></div></div><div class="head-actions">${watchButton(stock)}</div></div>`+demoBanner(stock)+
    `<div class="detail-layout"><div>${chartPanel(stock,true)}${scores(stock,['technical','fundamental','intelligence','market','edge'])}
      <div class="analysis-grid">${[
        ['Technical summary','BLOCK 3–6','価格や出来高の解析はまだ行っていません。上のチャートは価格・出来高の表示のみです。'],
        ['Fundamental summary','BLOCK 7','財務データは未取得です。架空銘柄だけ固定スコアがあり、実在銘柄のスコアは未算出です。'],
        ['Intelligence summary','BLOCK 8–9','外部予測者の登録・予測情報の取得・成績評価は未実装です。'],
        ['Market context','BLOCK 10','市場全体の判定は未実装です。個別株価の取得とは別に扱います。'],
      ].map(([title,block,text])=>`<section class="panel summary"><div class="panel-header"><h2>${title}</h2><span class="tag">${block}</span></div><div class="panel-body"><p>${text}</p></div></section>`).join('')}</div>
      ${scores(stock,['opportunity','risk','conviction','signal_diversity','conflict'])}
    </div><aside class="right-column"><section class="panel"><div class="panel-header"><div><h2>Scenario outlook</h2><div class="panel-subtitle">条件付きシナリオ / BLOCK 6</div></div></div><div class="panel-body">${[['Bull','上昇'],['Base','中立'],['Bear','下落']].map(([label,ja])=>`<div class="placeholder"><div class="placeholder-title">${label} <span class="tag">COMING SOON</span></div><p>${ja}シナリオ · 未算出<br>成立条件・否定条件・確率は未設定</p></div>`).join('')}</div></section><section class="panel"><div class="panel-header"><h2>Data provenance</h2></div><div class="panel-body"><div class="facts"><div class="fact"><span>Source</span><strong>${esc(stock.source)}</strong></div><div class="fact"><span>Currency</span><strong>${esc(stock.currency)}</strong></div><div class="fact"><span>Timeframe</span><strong>${state.interval==='1wk'?'週足':'日足'} / ${state.candles.length}本</strong></div><div class="fact"><span>Data as of</span><strong>${esc(stock.data_as_of||'未取得')}</strong></div></div><p class="setting-note">${stock.is_dummy?'架空銘柄です。実在企業・取引所の価格ではありません。':'個別銘柄の日次データです。取得日時と株価の基準日は異なります。'}</p></div></section></aside></div>`;
}

function settings() {
  const config=state.data?.settings ?? {theme:document.documentElement.dataset.theme,market:'JP',debug_mode:false};
  return heading('WORKSPACE PREFERENCES','設定','接続先と表示設定を管理します。')+
    `<div class="settings-layout"><section class="panel"><div class="panel-header"><h2>General settings</h2><span class="tag">BLOCK 2</span></div><div class="panel-body"><form id="settings-form">
      <div class="form-row"><div><label for="backend-url" class="form-label">Backend URL</label><p class="form-hint">空欄はPagesではブラウザ内デモ、Backend版では同じ接続先。別サーバーにはHTTPS URLを指定します。</p></div><input id="backend-url" name="backend" type="url" inputmode="url" placeholder="同一オリジン（推奨）" value="${esc(readBackend())}"></div>
      ${providerSettings(state)}<div class="form-row"><div><label for="theme" class="form-label">テーマ</label><p class="form-hint">${storageLabel()}へ保存します。</p></div><select name="theme" id="theme"><option value="dark" ${config.theme==='dark'?'selected':''}>Dark / ダーク</option><option value="light" ${config.theme==='light'?'selected':''}>Light / ライト</option></select></div>
      <div class="form-row"><div><label for="market" class="form-label">対象市場</label><p class="form-hint">BLOCK 2は日本株。架空銘柄と実データを別保存します。</p></div><select name="market" id="market"><option value="JP">日本株 / JP</option><option disabled>米国株 / Coming Soon</option><option disabled>ETF・FX・Crypto / Coming Soon</option></select></div>
      <div class="form-row"><div><label for="debug-mode" class="form-label">Debug Mode</label><p class="form-hint">APIソース・DB状態・取得データを画面下部に表示。計算結果は未実装と表示します。</p></div><label class="switch"><input id="debug-mode" name="debug" type="checkbox" ${config.debug_mode?'checked':''}> 有効にする</label></div>
      <div class="save-row"><p id="settings-status" role="status">保存時に接続確認を行います。</p><button class="btn primary" type="submit" id="save-settings">${icon('check')}設定を保存</button></div>
      </form><div style="margin-top:16px"><button class="btn small" data-action="reset-connection">接続先を同一オリジンに戻す</button></div></div></section>
    <aside class="right-column"><section class="panel"><div class="panel-header"><h2>Engine weights</h2><span class="tag">FUTURE CONFIG</span></div><div class="panel-body"><p class="setting-note">重みは${storageLabel()}で保持。統合計算と画面からの編集はBLOCK 11で実装します。</p>${config.weights?`<table class="weights-table"><thead><tr><th>Engine</th><th>5日</th><th>20日</th><th>60日</th></tr></thead><tbody>${['technical','fundamental','intelligence','market'].map(k=>`<tr><td>${scoreNames[k]}</td>${['5','20','60'].map(h=>`<td>${config.weights[h][k]}%</td>`).join('')}</tr>`).join('')}</tbody></table>`:'<p class="setting-note">Backendに接続すると保存済み設定を確認できます。</p>'}</div></section><section class="panel"><div class="panel-header"><h2>System status</h2></div><div class="panel-body"><div class="facts"><div class="fact"><span>Version</span><strong>0.2.1 / BLOCK 2</strong></div><div class="fact"><span>Database</span><strong>${state.data&&!state.error?(localDemo()?'Browser storage':'SQLite · Connected'):'未接続'}</strong></div><div class="fact"><span>External API</span><strong>${localDemo()?'未接続（公開デモ）':'J-Quants V2 Adapter'}</strong></div><div class="fact"><span>Analysis engines</span><strong>未実装</strong></div><div class="fact"><span>Service Worker</span><strong>未登録</strong></div></div></div></section></aside></div>`;
}

function errorView(message, stock=false) {
  return `<div class="error-box" role="alert"><h2>${stock?'銘柄情報を表示できません':'Backendへの接続を確認してください'}</h2><p>${esc(message)}</p><div class="head-actions"><button class="btn primary" data-action="refresh">再試行</button><a class="btn" href="#/settings">接続設定を開く</a><a class="btn" href="#/ranking">銘柄一覧へ</a></div></div>`;
}

function debugPanel() {
  if (!state.data?.settings.debug_mode) return '';
  return `<details class="debug-box"><summary>Debug information · API / DB / Raw data</summary><pre>${esc(JSON.stringify({
    api_source:state.data.health.source, backend:readBackend()||location.origin,
    data_as_of:state.data.health.data_as_of, database:state.data.health.database,
    calculation_result:'NOT IMPLEMENTED · BLOCK 2',pattern_score:null,raw_indicators:null,
    stock:state.detail || null, market_data:state.history || null,
  },null,2))}</pre></details>`;
}

async function render() {
  const epoch=++renderEpoch;
  chartObserver?.disconnect();
  parseRoute();
  const route=state.route;
  let body='';
  if (route==='settings') body=(state.error?errorView(state.error):'')+settings();
  else if (state.loading) body='<div class="loading"><div class="spinner"></div>Backendへ接続しています…</div>';
  else if (state.error) body=errorView(state.error);
  else if (route==='home') body=home();
  else if (route==='ranking'||route==='watchlist') body=ranking(route==='watchlist');
  else if (route==='stock') body='<div class="loading"><div class="spinner"></div>銘柄データを取得しています…</div>';
  else body=heading('PAGE NOT FOUND','ページが見つかりません','ナビゲーションから画面を選んでください。','<a class="btn" href="#/home">ホームへ</a>');
  app.innerHTML=shell(body+(route==='stock'?'':debugPanel()));
  document.title=`${navItems.find(([k])=>k===route)?.[2]||'ページ'} · STOCK EDGE`;
  if (!state.data||state.error||state.loading) return;
  if (route==='home'||route==='stock') {
    const ticker=route==='home'?state.data.ranking[0]?.ticker:state.ticker;
    if(!ticker) return;
    try {
      const history=await request(`/stocks/${encodeURIComponent(ticker)}/prices?interval=${state.interval}&basis=${state.basis}`);
      const stock=history.stock;
      if (epoch!==renderEpoch) return;
      state.detail=stock; state.candles=history.candles; state.history=history;
      if (route==='stock') app.innerHTML=shell(detail(stock)+debugPanel());
      else {
        for(const key of ['stocks','ranking','watchlist']) state.data[key]=state.data[key].map(s=>s.ticker===stock.ticker?stock:s);
        app.innerHTML=shell(home()+debugPanel());
      }
      const container=document.querySelector('#candlestick-chart');
      if (!container) return;
      const paint=()=>drawCandles(container,state.candles,state.range,state.history||{});
      paint(); chartObserver=new ResizeObserver(paint); chartObserver.observe(container);
    } catch (error) {
      if (epoch!==renderEpoch) return;
      if (route==='stock') app.innerHTML=shell(errorView(error.message,true));
      else {
        const chart=document.querySelector('#candlestick-chart');
        if (chart) {chart.className='chart-container empty';chart.textContent=error.message;}
        toast(error.message,true);
      }
    }
  }
}

async function boot() {
  state.loading=true; state.error=''; state.detail=null; state.history=null;
  await render();
  try {
    state.data=await loadFoundation();
    if(state.data.stocks.length && !state.data.stocks.some(s=>s.ticker===state.ticker)) state.ticker=state.data.stocks[0].ticker;
    document.documentElement.dataset.theme=state.data.settings.theme;
  } catch(error) {state.error=error.message;state.data=null;}
  state.loading=false;
  await render();
}

app.addEventListener('click',async event=>{
  const button=event.target.closest('button'); if(!button) return;
  if(button.dataset.action==='catalog-refresh') {await performMarketSearch(true);return;}
  if(button.dataset.import) {await importMarketStock(button);return;}
  if(button.dataset.interval) {
    state.interval=button.dataset.interval;state.history=null;await render();return;
  }
  if(button.dataset.chartRefresh) {
    button.disabled=true;
    try {
      const history=await request(`/stocks/${encodeURIComponent(button.dataset.chartRefresh)}/refresh?interval=${state.interval}&basis=${state.basis}`,{method:'POST'});
      state.history=history;state.data=await loadFoundation();
      toast(history.error_message||(localDemo()?'架空データの表示を更新しました':'価格データを取得し、DBへ保存しました'),!!history.error_code);
      await render();
    } catch(error) {toast(error.message,true);button.disabled=false;}
    return;
  }
  if (button.dataset.action==='refresh') {button.disabled=true;await boot();return;}
  if (button.dataset.action==='reset-connection') {
    try { saveBackend('');await boot();toast('接続先を同一オリジンに戻しました'); } catch(error) {toast(error.message,true);}
    return;
  }
  if (button.hasAttribute('data-range')) {
    state.range=Number(button.dataset.range);
    document.querySelectorAll('[data-range]').forEach(b=>{b.classList.toggle('active',b===button);b.setAttribute('aria-pressed',String(b===button));});
    const container=document.querySelector('#candlestick-chart');
    if(container) drawCandles(container,state.candles,state.range,state.history||{});
    return;
  }
  const ticker=button.dataset.watch;
  if (!ticker||state.busy.has(ticker)||!state.data) return;
  state.busy.add(ticker);button.disabled=true;
  const saved=state.data.watchlist.some(s=>s.ticker===ticker);
  try {
    await request(`/watchlist/${encodeURIComponent(ticker)}`,{method:saved?'DELETE':'PUT'});
    state.data.watchlist=await request('/watchlist');
    toast(saved?'ウォッチリストから削除しました':'ウォッチリストに保存しました');
  } catch(error) {toast(error.message+' 保存状態は再読込で確認してください。',true);}
  finally {state.busy.delete(ticker);await render();}
});

function updateResults() {
  const isWatch=state.route==='watchlist';
  const items=isWatch?state.data.watchlist:state.data.ranking;
  const filtered=filterStocks(items);
  document.querySelector('#stock-results').innerHTML=tableStocks(filtered,isWatch);
  document.querySelector('#result-count').textContent=`${filtered.length} / ${items.length}`;
}
app.addEventListener('input',event=>{if(event.target.id==='stock-filter'){state.query=event.target.value;updateResults();}});
app.addEventListener('change',event=>{if(event.target.id==='stock-sort'){state.sort=event.target.value;updateResults();}});
app.addEventListener('change',event=>{if(event.target.id==='price-basis'){state.basis=event.target.value;state.history=null;render();}});
app.addEventListener('input',event=>{if(event.target.id==='market-query') state.marketQuery=event.target.value;});

async function performMarketSearch(refresh=false) {
  if(state.searchBusy||!state.data) return;
  state.searchBusy=true;state.searchError='';await render();
  try {
    if(refresh) await request('/market/catalog/refresh',{method:'POST'});
    state.marketSearch=await request(`/market/search?q=${encodeURIComponent(state.marketQuery)}&limit=30`);
    if(refresh) toast(state.marketSearch.error_message||'銘柄一覧を取得して保存しました',!!state.marketSearch.error_code);
  } catch(error) {state.searchError=error.message;toast(error.message,true);}
  finally {state.searchBusy=false;await render();}
}

async function importMarketStock(button) {
  const ticker=button.dataset.import;
  const existing=state.marketSearch?.items.find(i=>i.ticker===ticker)?.imported;
  if(existing) {location.hash=`/stock/${encodeURIComponent(ticker)}`;return;}
  button.disabled=true;
  try {
    await request(`/stocks/${encodeURIComponent(ticker)}/refresh`,{method:'POST'});
    state.data=await loadFoundation();state.ticker=ticker;state.history=null;
    if(state.marketSearch) state.marketSearch.items=state.marketSearch.items.map(i=>i.ticker===ticker?{...i,imported:true}:i);
    location.hash=`/stock/${encodeURIComponent(ticker)}`;
    toast('価格を取得し、銘柄を追加しました');
  } catch(error) {toast(error.message,true);button.disabled=false;}
}

app.addEventListener('submit',async event=>{
  if(event.target.id==='market-search-form') {event.preventDefault();state.marketQuery=event.target.elements.query.value;await performMarketSearch();return;}
  if(event.target.id!=='settings-form') return;
  event.preventDefault();
  const form=event.target, button=form.querySelector('[type=submit]'), status=form.querySelector('#settings-status');
  const backendInput=form.elements.backend.value;
  button.disabled=true;status.textContent='接続と保存を確認しています…';
  try {
    const backend=normalizeBackend(backendInput);
    await loadFoundation(backend);
    const config=await request('/settings',{method:'PATCH',body:JSON.stringify({theme:form.elements.theme.value,market:'JP',debug_mode:form.elements.debug.checked,market_data_provider:form.elements.provider.value})},backend);
    saveBackend(backend);state.data=await loadFoundation(backend);state.error='';state.loading=false;state.marketSearch=null;state.history=null;state.marketQuery='';state.searchError='';
    document.documentElement.dataset.theme=config.theme;
    await render();toast('設定を保存しました');
    const savedStatus=document.querySelector('#settings-status');
    if(savedStatus) savedStatus.textContent=localDemo()?'設定をこのブラウザへ保存しました。':'接続確認済み · 設定をDBへ保存しました。';
  } catch(error) {status.textContent=error.message;toast(error.message,true);}
  finally {button.disabled=false;}
});

window.addEventListener('hashchange',()=>{state.detail=null;state.history=null;render();window.scrollTo(0,0);});
document.querySelector('.skip-link').addEventListener('click',event=>{
  event.preventDefault();
  const main=document.querySelector('#main');
  main?.focus();main?.scrollIntoView({block:'start'});
});
boot();
