const esc = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const stamp = value => value ? new Intl.DateTimeFormat('ja-JP',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',timeZone:'Asia/Tokyo'}).format(new Date(value))+' JST' : '未取得';
const age = seconds => seconds == null ? '未取得' : seconds<60 ? '1分未満前' : seconds<3600 ? Math.floor(seconds/60)+'分前' : Math.floor(seconds/3600)+'時間前';
export const sourceLabel = stock => stock.is_dummy ? 'DEMO' : 'J-QUANTS';

export function seriesStatus(history) {
  if (!history) return '<div class="data-status">データの取得情報を読み込み中…</div>';
  const labels={seed:'初期データ',fresh:'キャッシュ有効',stale:'キャッシュ期限超過',stale_error:'更新失敗 · 保存済みデータを表示'};
  return `<div class="data-status ${history.cache_status==='stale_error'?'warning':''}"><div class="data-facts"><span><strong>${esc(history.source)}</strong></span><span>価格基準日 <strong>${esc(history.data_as_of)}</strong></span><span>取得 ${stamp(history.fetched_at)} (${age(history.cache_age_seconds)})</span><span>${labels[history.cache_status]}</span></div>${history.error_message?`<p role="alert">${esc(history.error_message)}${history.retry_after?' 再試行の目安 '+history.retry_after+'秒後。':''}</p>`:''}<p>${history.warnings.map(esc).join(' / ')}</p></div>`;
}

export function searchResults(result) {
  if (!result) return '<p class="setting-note">銘柄一覧を更新するか、コード・社名・業種で検索してください。</p>';
  return `<div class="search-meta">${result.total_matches}件一致 / 一覧${result.total_catalog}件 · 一覧取得 ${stamp(result.fetched_at)}${result.data_as_of?' · 一覧基準日 '+esc(result.data_as_of):''}</div>${result.error_message?`<p class="search-error" role="alert">${esc(result.error_message)} 保存済みの銘柄一覧を表示しています。</p>`:''}${!result.provider.configured?'<p class="setting-note">JQUANTS_API_KEYをBackendの.envへ設定して再起動すると、実データを取得できます。</p>':''}<div class="lookup-list">${result.items.length?result.items.map(i=>`<div class="lookup-row"><div><strong>${esc(i.company)}</strong><span>${esc(i.ticker)} · ${esc(i.sector)} · ${i.is_dummy?'架空':esc(i.exchange)}</span></div><button class="btn small" data-import="${esc(i.ticker)}">${i.imported?'詳細を開く':'価格を取得して追加'}</button></div>`).join(''):'<p class="setting-note">該当する銘柄はありません。実データは「銘柄一覧を更新」してから検索してください。</p>'}</div>`;
}

export function marketPanel(state) {
  const selected=state.data?.settings.market_data_provider || 'dummy';
  const provider=state.data?.providers?.providers.find(p=>p.id===selected);
  return `<section class="panel market-search-panel"><div class="panel-header"><div><h2>Market data / 銘柄検索</h2><div class="panel-subtitle">${esc(provider?.name||selected)} · ${esc(provider?.message||'')}</div></div><button class="btn small" data-action="catalog-refresh" ${state.searchBusy?'disabled':''}>銘柄一覧を更新</button></div><div class="panel-body"><form id="market-search-form" class="lookup-form"><label class="sr-only" for="market-query">市場の銘柄を検索</label><input id="market-query" name="query" maxlength="120" placeholder="コード・社名・業種で銘柄を検索" value="${esc(state.marketQuery)}"><button class="btn primary" type="submit" ${state.searchBusy?'disabled':''}>検索</button></form>${state.searchError?`<p class="search-error" role="alert">${esc(state.searchError)}</p>`:''}<div id="market-search-results" aria-live="polite">${state.searchBusy?'<p class="setting-note">データを確認しています…</p>':searchResults(state.marketSearch)}</div></div></section>`;
}

export function providerSettings(state) {
  const selected=state.data?.settings.market_data_provider || 'dummy';
  const provider=state.data?.providers?.providers.find(p=>p.id===selected);
  const local=state.data?.health.runtime==='browser-demo';
  return `<div class="form-row"><div><label for="market-provider" class="form-label">株価データ提供元</label><p class="form-hint">${local?'Pagesデモは架空データです。実データにはHTTPS Backend URLを設定してください。':'Dummyと実データを分離して保存します。実データのスコアは未算出です。'}</p></div><select id="market-provider" name="provider"><option value="dummy" ${selected==='dummy'?'selected':''}>DummyProvider / 架空</option><option value="jquants" ${selected==='jquants'?'selected':''} ${local?'disabled':''}>J-Quants V2 / 実データ</option></select></div><p class="setting-note">${esc(provider?.message||'')} ${selected==='jquants'?(provider?.configured?'APIキー設定あり（値は表示しません）。':'APIキー未設定。Backendの.envへ設定し再起動してください。'):''}</p>`;
}
