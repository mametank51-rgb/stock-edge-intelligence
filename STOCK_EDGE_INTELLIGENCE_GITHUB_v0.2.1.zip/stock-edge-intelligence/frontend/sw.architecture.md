# PWA preparation only

BLOCK 1 does not register a service worker. No API or settings response is cached in the browser.
A future worker must version shell assets, keep writes network-only, avoid caching private API responses,
and explicitly label cached market data with its original timestamp. This file is documentation, not runnable code.
