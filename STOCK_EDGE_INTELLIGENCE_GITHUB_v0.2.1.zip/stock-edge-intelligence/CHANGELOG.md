# CHANGELOG

## 0.2.1 — 2026-10-24 / GitHub公開準備

BLOCK 2を維持して公開・配布方法を修正。BLOCK 3以降は未実装。

- GitHub Pages用の明示的なBrowser Demoモードを追加。既存5画面・架空OHLCV・週足・検索・watch/settings保存をブラウザ内で操作可能。
- 本番用Frontendは従来どおりBackendへ通信。明示したBackendの失敗時にデモへ自動置換しない。
- リポジトリ名付きURLに対応する相対asset/manifest/iconパス。
- Pages配信内容は承認済みの静的ファイルと、seedから生成する固定架空JSONだけ。
- DBを公開ZIPから完全除外し、初回起動で作成。旧DB migration用の架空fixtureもSQLiteバイナリからSQLへ変換。
- .gitignore強化、公開ファイル検査、DB・backup・ログ・秘密設定・symlink等の除外。
- GitHub Actions CI（Ubuntu/Windows、Python 3.12、Node 24）と手動Pages公開workflow。
- README、GITHUB_PUBLISH、SECURITY、CONTRIBUTINGと引継ぎ資料。
- OSSライセンスは未選択。リポジトリ作成・push・実公開は行っていない。

変更：backend/config.py、frontend/index.html、manifest.webmanifest、assets/api.js、app.js、market-view.js、package.json、scripts/package.py、tests/test_market_data.py、.gitignore、各文書。
追加：.github/workflows/ci.yml、pages.yml、.gitattributes、.editorconfig、frontend/assets/deployment.json、demo-core.js、demo-api.js、scripts/build_pages.py、check_public_source.py、tests/support.py、__init__.py、fixtures/block1_seed.sql、test_demo.mjs、test_transport.mjs、test_publication.py、GITHUB_PUBLISH.md、SECURITY.md、CONTRIBUTING.md。
削除：配布対象のtests/fixtures/block1_seed.db。利用中のdatabase/stock_edge.dbはローカルに維持し、配布・Git対象から除外。

## 0.2.0 — 2026-10-24 / BLOCK 2 MARKET DATA ENGINE

BLOCK 1完成版をベースに追加。BLOCK 3以降には進んでいません。

### 追加

- MarketDataProvider Protocol、DummyProvider、公式J-Quants V2 Adapter。
- 国内株式の銘柄一覧取得・保存・検索、英字/全角/4桁/5桁コードの正規化。
- 日足取得、未調整/調整済みOHLCV保存、週足集約、表示切替。
- 価格基準日と取得日時、キャッシュ状態・取得エラー・無約定スキップ件数。
- TTLキャッシュ、Last Known Data、失敗時の元日時維持、連続再試行抑制。
- 429/cooldown、契約別の呼出し制限、timeout、限定retry、pagination、全件検証後の保存。
- 銘柄更新ごとの排他、原子的な価格スナップショット置換。
- v1→v2移行、移行前のSQLiteバックアップ、新3テーブル。
- J-Quants選択/キー未設定状態のUI。実在銘柄のスコアはnull、架空データと混在させない表示。
- APIキーを保持しないFrontend、固定公式endpointへのBackend通信。
- 58件のPythonテスト（既存19件を維持）、JS接続先10項目、ブラウザ/390px検証。

### 変更ファイル

既存変更：backend/config.py、models.py、repository.py、main.py、requirements.txt、constraints.txt、.env.example、
frontend/index.html、manifest.webmanifest、assets/api.js、app.js、chart.js、styles.css、
package.json、scripts/package.py、tests/test_foundation.py、README.md、CHANGELOG.md、FEATURES.md、NEXT_BLOCK.md、TEST_REPORT.md、PROJECT_TREE.md、PACKAGE_CHECK.txt。

新規：backend/providers.py、market_models.py、market_data.py、database/migrations/002_market_data.sql、
frontend/assets/market-view.js、tests/test_market_data.py、tests/fixtures/block1_seed.db、pytest.ini、MIGRATION.md、DATA_PROVIDERS.md。

配布用database/stock_edge.dbはv2の清潔な初期DBです。利用中DBを上書きしない更新手順をMIGRATION.mdへ記載。
機械的なファイル差分はPROJECT_TREE.mdにも記録します。

### 検証限界

実APIキーがないため、実接続・実価格の照合は未検証です。公式仕様とMockTransportの結果を分けて報告。
Windows/macOS/Android実機も未検証。PWA、公開配信、分析/予測は未実装です。

## 0.1.0 — 2026-10-24 / BLOCK 1 APP FOUNDATION

初版。BLOCK 1のみ実装。

### 追加

- FastAPI Backendと同一originで配信する分割HTML/CSS/ES Modules Frontend。
- HOME / RANKING / STOCK DETAIL / WATCHLIST / SETTINGSのhash routing。
- Dark Professional UI、Lightテーマ、モバイル用ボトムナビゲーション。
- SQLite 4テーブル、スキーマバージョン1、Repository Pattern、初期化の冪等性。
- 架空銘柄8件、整合性を持つ合成日足OHLCV 1,280件。
- 自前SVGローソク足/出来高チャート、30/60/160日切替、価格確認。
- 必須5GET API、価格履歴GET、ウォッチリストGET/PUT/DELETE、設定PATCH。
- DB保存、重複登録防止、削除済みリストを再seedしない動作。
- 10スコアと将来拡張用のデータ契約。重みのDB保持とAPIバリデーション。
- 接続確認後のBackend URL保存、無効URL拒否、同一origin復旧操作。
- エラー表示、通信タイムアウト、リクエスト競合時の古い詳細表示の抑止。
- logs/、.env.example、起動スクリプト、PWA用manifest/icon/設計メモ。
- README、FEATURES、NEXT_BLOCK、TEST_REPORT、PROJECT_TREE。
- API/DB自動テスト19ケース、接続URL検証10項目。

### 動作確認で修正

- SQLite接続を明示的にcloseし、繰返しAPIアクセス時の接続リークを防止。
- モバイルのチャート期間ボタンが改行されない配置へ調整。
- スキップリンクがhash routingを書き換えないよう修正。
- 不正なURIエンコードを含む銘柄URLで例外停止しないよう修正。

### 先送り

外部データ取得・分析・シナリオ生成・予測者評価・Meta Edge計算等、BLOCK 2〜16は未実装。

### 変更ファイル

初版のため`PROJECT_TREE.md`掲載ファイルをすべて新規追加。
次回以降は既存ファイルをベースに変更差分をここへ追記すること。
