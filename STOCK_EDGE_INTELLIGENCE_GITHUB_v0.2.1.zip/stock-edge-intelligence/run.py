"""One-process launcher: serves FastAPI, SQLite, and frontend together."""
import os
import uvicorn

from backend.config import ROOT  # loads .env before reading host/port

if __name__ == "__main__":
    uvicorn.run("backend.main:app", host=os.getenv("STOCK_EDGE_HOST", "127.0.0.1"),
                port=int(os.getenv("STOCK_EDGE_PORT", "8000")))
