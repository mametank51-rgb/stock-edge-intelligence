# BLOCK 1 → BLOCK 2 データ引継ぎ

公開準備版v0.2.1のZIPにはDBを含めません。新規利用なら起動時に初期DBを自動作成します。
以前のウォッチリスト・設定を引き継ぐ場合は、下記の手順を使います。

1. BLOCK 1のアプリを停止する（ターミナルでCtrl+C）。
2. BLOCK 1のフォルダ全体を別の場所へバックアップする。
3. BLOCK 2のZIPを**別フォルダ**へ展開する。
4. BLOCK 1の`database/stock_edge.db`を、まだ起動していないBLOCK 2のdatabase/へコピーする。
   すでに新規DBができている場合はそれを別名へ退避してからコピーしてください。利用中DBを公開ソースへ含めないでください。
5. 独自の`.env`があれば必要な設定を引き継ぐ。`STOCK_EDGE_DB`に別パスを設定していた場合は、そのファイルが対象になります。
6. BLOCK 2の`start.bat`または`sh start.sh`で起動する。
7. `/health`の`database.schema_version`が`2`であること、ウォッチリストとテーマが残ることを確認する。

## 自動移行の内容

- v1のstocks / price_history / watchlist / settingsを維持。
- `instruments`（銘柄一覧）、`price_adjustments`（調整済みOHLCV）、`data_cache`（取得メタデータ）を追加。
- 架空データの価格を調整済みテーブルへ初期転記。元の価格履歴を変更しない。
- 既存設定にproviderがなければDummyProviderを既定値として扱う。
- v1 DBは、移行前に`database/backups/stock_edge.db.v1.bak`へSQLite backup APIで保存。
- 移行SQLはトランザクションで適用し、成功時だけ`user_version=2`とする。
- すでにv2なら再移行や再seedを行わない。
- アプリより新しいバージョンのDBは開かず、ダウングレード事故を防ぐ。

`database/schema.sql`は初期v1スキーマです。新規DBも初期化後に
`database/migrations/002_market_data.sql`を適用してv2へ進みます。

## 移行失敗時

ログを確認し、アプリを停止してください。最初に保存したフォルダのバックアップでBLOCK 1を起動できます。
v2になったDBをそのままBLOCK 1で開くことはできません。

## 検証済み

実際のBLOCK 1配布DBの架空データを、テスト用SQL fixtureとして同梱しています（tests/fixtures/block1_seed.sql）。
このDBのテーマ・Debug・重みを変更し、ウォッチリストを全削除した状態で移行を検証しました。
全1,280行の価格履歴・stocksの全列が移行前と一致し、設定と空リストも保持されました。
バックアップはschema version 1のままであることも確認しています。
