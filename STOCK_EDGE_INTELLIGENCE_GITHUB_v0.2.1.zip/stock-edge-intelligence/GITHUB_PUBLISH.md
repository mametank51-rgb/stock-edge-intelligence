# GitHub公開手順 — v0.2.1

この成果物は公開前の準備版です。リポジトリ作成・push・Pages公開はまだ実行していません。
既存のBLOCK 2を維持し、BLOCK 3以降には進んでいません。

## 何を公開できるか

| 内容 | 公開方法 | 動作 |
|---|---|---|
| 完全ソース | GitHubリポジトリ | clone/ダウンロード後にPythonで起動 |
| 操作できるデモ | GitHub Pages | 架空8銘柄、チャート、日足/週足、検索、設定、watchlist |
| 実データ利用 | 別途起動するBackend | J-Quantsキーはサーバー側のみ。実接続は未検証 |

GitHub Pagesは静的配信です。Python/FastAPI・SQLiteをPages上で起動する構成ではありません。
公開デモは明確にLOCAL DEMOと表示し、閲覧者のブラウザへ設定・watchlistを保存します。
ブラウザのデータ削除やサイトのパス変更で保存内容は失われます。利用者間で共有しません。
価格は固定の架空値です。「価格を更新」はサンプルの再表示であり、実株価取得ではありません。

## 1. 公開用ソースを用意

1. 配布ZIPを新しいフォルダへ展開します。
2. 中の`stock-edge-intelligence`フォルダをリポジトリのルートとして使います。
3. `.github/workflows/`を含む隠し設定ファイルもそのまま保持します。
4. 利用中のDBや.envをこのフォルダへ移す必要はありません。Backendを起動すると初期DBが自動作成されます。

元の作業フォルダ全体をアップロードせず、scripts/package.pyが作る公開用ZIPの内容を使ってください。
既存DBを使い続ける場合はローカル側で保持し、MIGRATION.mdに従って別途引き継ぎます。

## 2. リポジトリへ登録

GitHubで空のリポジトリを作成します。作成時にREADMEを自動生成しないと初回pushが簡単です。
展開したフォルダで次を実行します。

```bash
git init -b main
git add .
git status --short
python scripts/check_public_source.py
git commit -m "Prepare Stock Edge Intelligence Block 2 for GitHub"
git remote add origin https://github.com/OWNER/REPO.git
git push -u origin main
```

OWNER/REPOは自分が作成したリポジトリに置き換えます。認証は自分のGitHub環境で行います。
このコード内にGitHubトークンを埋め込む必要はありません。

`check_public_source.py`はGit管理下のファイルを検査します。
.env、DB、backup、ログ、秘密鍵、検出可能な一部トークン形式があると停止します。
包括的なsecret検出の保証ではないため、git statusと初回コミット内容も確認してください。
過去にコミットした秘密情報は.gitignoreだけでは消えません。

## 3. CIを確認

push / Pull Requestで`.github/workflows/ci.yml`が実行されます。
UbuntuとWindowsのPython 3.12・Node 24で、Pythonテスト、JS構文、Pagesビルド、デモロジック、公開ファイル検査を行います。
実APIキーやGitHub Secretsの登録は不要です。
GitHub上のActions実行は、この成果物のローカル検証とは別に確認してください。

## 4. GitHub Pagesでデモを公開

1. リポジトリのSettings → Pagesを開く。
2. Build and deploymentのSourceを **GitHub Actions** にする。
3. Actions → **Deploy Pages demo** → Run workflowを選ぶ。
4. デフォルトブランチ（通常main）で実行する。
5. 完了後、GitHubが表示する公開URLを開く。

Pages公開は手動実行だけです。通常のpushやPRから自動公開しません。
公開するartifactは`dist/pages`だけで、Backend、DB、テストfixture、.env、ソース一式は含めません。
リポジトリ名を含むサブパスでも動くよう、HTML・manifest・アイコンは相対パスで参照します。
GitHub Pagesの公開範囲はGitHub側の設定に従います。

## 5. Backend版の起動

Windowsはstart.bat、macOS/Linuxはsh start.sh。
http://127.0.0.1:8000 を開きます。公開版ZIPにDBはありませんが、初回起動でSQLiteを作成します。
JQUANTS_API_KEYはBackendの.envへ設定して再起動し、提供元をJ-Quantsへ切り替えます。

Pagesの設定でHTTPS Backend URLを保存すると、そのBackendへ接続する経路も維持しています。
BackendのCORSにはPagesのorigin（例：`https://OWNER.github.io`。リポジトリのパスは付けない）を明示します。
HTTPSのPagesからHTTPのBackendへ接続することはできません。
Backend接続に失敗したとき、実データをブラウザ内デモで自動的に置き換えることはありません。
空欄へ戻すとPagesのブラウザ内デモへ戻ります。

Backendは現状ローカル/閉域・1ユーザー用です。一般公開するBackendの認証・ユーザー分離は別途必要です。
今回、認証のないBackendをインターネットへ公開する作業は行っていません。

## ローカルでPagesを確認

```bash
python -m pip install -r requirements-dev.txt -c constraints.txt
python scripts/build_pages.py
python -m http.server 5173 --directory dist/pages
```

http://127.0.0.1:5173 で静的デモを確認できます。Node.jsがあれば`npm run check`と`npm test`も実行できます。
Python Backendを同時に起動する必要はありません。

## ライセンスとデータ

MIT等のオープンソースライセンスは今回選定していません。
再利用を許諾するOSSとして公開する場合は、権利者がライセンスを選びLICENSEを追加してください。
J-Quants由来の実価格データは公開artifactに埋め込みません。利用範囲は自分の契約を確認してください。

公式資料：

- [GitHub Pagesサイトの作成](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)
- [GitHub ActionsによるPages公開](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages)
