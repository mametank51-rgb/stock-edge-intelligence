// Optional preview launcher. The normal user entry point is run.py / start.bat.
import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import {resolve} from 'node:path';
const args = process.argv.slice(2);
const option = (name, fallback) => args.includes(name) ? args[args.indexOf(name)+1] : fallback;
const local = process.platform === 'win32' ? '.venv/Scripts/python.exe' : '.venv/bin/python';
const python = existsSync(local) ? local : (process.env.CODEX_PRIMARY_RUNTIME_PYTHON || (process.platform==='win32'?'python':'python3'));
const env = {...process.env};
if (existsSync('preview_dependencies')) env.PYTHONPATH = [resolve('preview_dependencies'), env.PYTHONPATH].filter(Boolean).join(process.platform==='win32'?';':':');
const child = spawn(python, ['-m','uvicorn','backend.main:app','--host',option('--host','127.0.0.1'),'--port',option('--port','8000')], {stdio:'inherit',env});
for (const signal of ['SIGINT','SIGTERM']) process.on(signal,()=>child.kill(signal));
child.on('error',error=>{console.error(error.message);process.exitCode=1;});
child.on('exit',code=>process.exit(code??1));
