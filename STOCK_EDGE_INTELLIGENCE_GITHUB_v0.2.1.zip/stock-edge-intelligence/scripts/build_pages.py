"""Build ONLY approved static files and deterministic fictional fixtures for GitHub Pages."""
import argparse
import json
import shutil
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
ASSETS={'app.js','api.js','chart.js','styles.css','market-view.js','demo-api.js','demo-core.js'}


def build(destination=None):
    from backend.models import AppSettings
    from backend.seed import fixtures
    destination=Path(destination or ROOT/'dist/pages').resolve()
    if destination==ROOT or ROOT.is_relative_to(destination) or destination.is_relative_to(ROOT/'frontend'):
        raise ValueError('Build output must not overwrite source')
    if destination.exists():
        if destination.is_symlink():
            raise ValueError('Build output cannot be a symlink')
        shutil.rmtree(destination)
    (destination/'assets').mkdir(parents=True)
    (destination/'icons').mkdir()
    for name in ('index.html','manifest.webmanifest'):
        shutil.copyfile(ROOT/'frontend'/name,destination/name)
    for name in ASSETS:
        source=ROOT/'frontend/assets'/name
        if source.is_symlink():
            raise ValueError('Symlink asset rejected')
        shutil.copyfile(source,destination/'assets'/name)
    shutil.copyfile(ROOT/'frontend/icons/icon.svg',destination/'icons/icon.svg')
    (destination/'.nojekyll').write_text('',encoding='utf-8')
    (destination/'assets/deployment.json').write_text(json.dumps({'mode':'pages-demo'}),encoding='utf-8')
    stocks,history=fixtures()
    data={'schema':'stock-edge-pages-demo-v1','settings':AppSettings().model_dump(mode='json'),
          'stocks':[{**s.model_dump(mode='json'),'data_as_of':s.updated_at.date().isoformat()} for s in stocks],
          'history':{ticker:[c.model_dump(mode='json') for c in candles] for ticker,candles in history.items()}}
    (destination/'assets/demo-data.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    return destination


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path)
    print('Built static demo:',build(parser.parse_args().output))
