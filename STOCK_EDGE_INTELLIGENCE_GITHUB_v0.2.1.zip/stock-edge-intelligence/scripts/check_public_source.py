"""Check tracked files (or the source allowlist outside Git) without printing secret values."""
import re
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from scripts.package import forbidden, source_files


def audit(root=ROOT,paths=None):
    if paths is None:
        if (root/'.git').exists():
            output=subprocess.check_output(['git','ls-files','-z'],cwd=root)
            paths=[root/name for name in output.decode().split('\0') if name]
        else: paths=source_files(root)
    problems=[]
    for path in paths:
        relative=path.relative_to(root)
        if forbidden(relative) or path.is_symlink():
            problems.append(relative.as_posix()+': private/generated file');continue
        if not path.is_file(): continue
        content=path.read_bytes()
        if b'\0' in content: problems.append(relative.as_posix()+': binary content');continue
        text=content.decode('utf-8',errors='replace')
        # High confidence formats only. No claim of exhaustive secret detection.
        if re.search(r'gh[pousr]_[A-Za-z0-9]{24,}|github_pat_[A-Za-z0-9_]{30,}|-----BEGIN (?:RSA |EC )?PRIVATE KEY-----',text):
            problems.append(relative.as_posix()+': credential-like content')
        if relative.as_posix()=='.env.example' and re.search(r'^JQUANTS_API_KEY[ \t]*=[ \t]*[^\s#]+',text,re.M):
            problems.append(relative.as_posix()+': example API key is not empty')
    return problems


if __name__=='__main__':
    errors=audit()
    if errors:
        print('\n'.join(errors));raise SystemExit(1)
    print('PASS: publishable source contains no blocked files or detected credentials')
