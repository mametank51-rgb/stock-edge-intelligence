"""Create a GitHub-ready source ZIP. Runtime databases and secrets are NEVER included."""
import argparse
import hashlib
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
FOLDERS={'backend','database','frontend','tests','scripts','logs','.github'}
ROOT_FILES={
    'README.md','CHANGELOG.md','FEATURES.md','NEXT_BLOCK.md','TEST_REPORT.md','PROJECT_TREE.md',
    'PACKAGE_CHECK.txt','MIGRATION.md','DATA_PROVIDERS.md','GITHUB_PUBLISH.md','SECURITY.md',
    'CONTRIBUTING.md','requirements.txt','requirements-dev.txt','constraints.txt','run.py',
    'start.bat','start.sh','package.json','pytest.ini','.env.example','.gitignore',
    '.gitattributes','.editorconfig',
}
FORBIDDEN_PARTS={'.git','.venv','node_modules','__pycache__','.pytest_cache','preview_dependencies','backups'}


def forbidden(relative):
    name=relative.name.lower()
    if any(part in FORBIDDEN_PARTS for part in relative.parts): return True
    if name.startswith('.env') and relative.as_posix()!='.env.example': return True
    if any(s in name for s in ('.db','.sqlite')) or name.endswith(('.bak','.pem','.key','.pyc','.log','.zip','.tar','.gz')): return True
    if name.startswith('qa-'): return True
    if relative.parts[0]=='logs' and name!='.gitkeep': return True
    return False


def source_files(root=ROOT):
    result=[]
    # Walk approved folders only, never the user's environment or build output.
    candidates=[root/name for name in ROOT_FILES]
    for folder in FOLDERS:
        directory=root/folder
        if directory.exists(): candidates.extend(directory.rglob('*'))
    for path in sorted(set(candidates)):
        relative=path.relative_to(root)
        if forbidden(relative): continue
        if path.is_symlink(): raise ValueError('Symlink in publishable source: '+relative.as_posix())
        if path.is_file(): result.append(path)
    return result


def package(destination=None):
    destination=Path(destination or ROOT/'dist/STOCK_EDGE_INTELLIGENCE_GITHUB.zip').resolve()
    destination.parent.mkdir(parents=True,exist_ok=True)
    files=source_files(ROOT);records=[]
    from scripts.check_public_source import audit
    errors=audit(ROOT,files)
    if errors: raise ValueError('Source audit failed: '+'; '.join(errors))
    with ZipFile(destination,'w',ZIP_DEFLATED) as archive:
        for path in files:
            relative=path.relative_to(ROOT).as_posix();content=path.read_bytes()
            records.append(hashlib.sha256(content).hexdigest()+'  '+relative)
            archive.writestr('stock-edge-intelligence/'+relative,content)
        archive.writestr('stock-edge-intelligence/SHA256SUMS.txt','\n'.join(records)+'\n')
    return destination,len(files)+1


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('destination',nargs='?',type=Path)
    path,count=package(parser.parse_args().destination)
    print(f'Created {path.name}: {count} source files, {path.stat().st_size:,} bytes; no runtime DB')
