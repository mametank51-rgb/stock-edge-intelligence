# 実装済み・未実装 / v0.2.1

## GitHub公開準備で追加

- GitHub Pages用の明示的なブラウザ内デモ。架空の5画面・チャート・日足/週足・検索・watch/settings保存。
- リポジトリ名付きサブパスへの対応、外部Backend接続経路の維持。
- CIと手動Pages公開workflow。公開artifactは静的デモのみ。
- 公開ソースのDB/backup/ログ/秘密設定除外、SQL形式の架空migration fixture。
- 公開ファイル検査、GITHUB_PUBLISH/SECURITY/CONTRIBUTING。

GitHub上のCI実行・Pages実公開は未実施。Backend認証や新しい分析BLOCKは追加していません。

## BLOCK 1から維持

- Frontend / Backend / SQLite、5画面のhash routing。
- Dark/Light、モバイル下部ナビ、Debug。
- 架空8銘柄・合成OHLCV・固定Dummyスコア。
- ローソク足/出来高・表示範囲切替。
- ウォッチ登録/削除/重複防止/DB保存/再起動保持。
- 設定保存・Backend URLの検証・接続復旧。
- 10スコアと将来用契約、重みのDB保存。
- ログ、.env.example、manifest/icon。Service Workerは未登録。

## BLOCK 2で追加

| 分類 | 実装 |
|---|---|
| Provider | Protocol、Dummy、J-Quants公式V2用Adapter |
| 銘柄検索 | 一覧取得/保存、コード・日本語/英語名・業種の検索 |
| コード | 4桁→5桁、英字、全角、.T入力。5桁は末尾維持 |
| 価格 | 日足OHLCV、未調整/調整済み、調整係数、単一価格時の騰落率null |
| 週足 | 月曜始まりOHLCV集約、観測日数、境界/進行週フラグ |
| キャッシュ | TTL、明示更新、日足/週足共通データ、Last Known Data |
| メタデータ | 価格基準日、取得成功日時、最終試行日時、状態、無約定スキップ数 |
| 異常系 | 認証、429、timeout、5xx、不正JSON、空、重複、OHLC不整合 |
| 整合性 | 全ページ検証後の原子保存、日付一意、銘柄更新排他 |
| DB移行 | v1→v2、自動バックアップ、既存テーブル/利用設定の保持 |
| UI | 市場検索、提供元選択、足種/調整切替、元データと失敗理由の表示 |

J-Quantsは実キー接続未検証。AdapterのHTTPモック検証と、Dummyの実HTTP/ブラウザ確認を実施しました。
実在銘柄にDummyの分析スコアを割り当てません。未計算はnull（—）です。

## 未実装

| BLOCK | 内容 |
|---|---|
| 3 | SMA/EMA/RSI/MACD/Bollinger/ATR/basic trend |
| 4 | Swing/Support/Resistance/Trendline等 |
| 5 | Double Bottom/Double Top/Triangle |
| 6 | 条件付きTechnical Scenario |
| 7 | Fundamental/Revision |
| 8 | Intelligence Provider/予測登録 |
| 9 | 予測者の成績評価 |
| 10 | Market Regime |
| 11 | Meta Edge |
| 12 | 実解析ランキング |
| 13 | 不変Prediction Snapshot |
| 14 | Backtest |
| 15 | Advanced Analysis |
| 16 | Vision Assist |

Market Today/Recent analysis/各解析summary/Scenarioは未実装またはUIサンプルと明示しています。
認証、定期収集、分散ロック・分散rate制御、厳密な取引所カレンダー、APK/EXE、PWAオフライン、公開配信は対象外です。
